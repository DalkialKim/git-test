/* 채널별 회차 신청/변경 현황	DA-012 */
SELECT REQ_CHNL
     , NEW_CHG_CL
	  , FORMAT(REQ_TS,0)  AS REQ_TS
	  , FORMAT(REQ_CNT,0) AS REQ_CNT
  FROM BDS.ZBIL_CHNL_TS_REQ_STC
 WHERE REQ_YM = '202011'
   AND REQ_TS = if('9' = '9', REQ_TS, '9')
 ORDER BY REQ_CHNL, NEW_CHG_CL, REQ_TS
;

SELECT *
FROM BDS.ZBIL_CHNL_TS_REQ_STC
;

/* 카드사별 인출오류 현황	DA-013 */
SELECT DRW_YM
	 , CARD_NM
	, FORMAT(DRW_REQ_CNT,0) AS DRW_REQ_CNT
	, FORMAT(NOR_DRW_CNT,0) AS NOR_DRW_CNT
	, FORMAT(ERR_DRW_CNT,0) AS ERR_DRW_CNT
	, FORMAT(DRW_REQ_AMT,0) AS DRW_REQ_AMT
	, FORMAT(NOR_DRW_AMT,0) AS NOR_DRW_AMT
	, FORMAT(ERR_DRW_AMT,0) AS ERR_DRW_AMT
	, AMT_DRW_RT
  FROM BDS.ZBIL_CARD_CO_DRW_STC
 WHERE DRW_YM BETWEEN '202005' AND '202011'
   AND CARD_NM = IF('전체' = '전체', CARD_NM, '삼성카드')
 ORDER BY DRW_YM, CARD_CD
;


--
select DRW_YM
	 , CARD_NM
	 , DRW_REQ_CNT
	 , NOR_DRW_CNT
	 , ERR_DRW_CNT
	 , DRW_REQ_AMT
	 , NOR_DRW_AMT
	 , ERR_DRW_AMT
	 , AMT_DRW_RT
  from BDS.ZBIL_CARD_CO_DRW_STC
 where drw_ym between '202005' and '202011'
   and card_nm = if('전체' = '전체', card_nm, '삼성카드')
 order by drw_ym, card_cd
;


select ifnull(DRW_YM, '전체합계') as DRW_YM
	 , ifnull(CARD_NM, '합계') as CARD_NM
	 , DRW_REQ_CNT
	 , NOR_DRW_CNT
	 , ERR_DRW_CNT
	 , DRW_REQ_AMT
	 , NOR_DRW_AMT
	 , ERR_DRW_AMT
	 , AMT_DRW_RT
     , NOR_DRW_AMT / 
from
(
	select DRW_YM
         , CARD_NM
		 , sum(DRW_REQ_CNT) as DRW_REQ_CNT 
		 , sum(NOR_DRW_CNT) as NOR_DRW_CNT
		 , sum(ERR_DRW_CNT) as ERR_DRW_CNT
		 , sum(DRW_REQ_AMT) as DRW_REQ_AMT
		 , sum(NOR_DRW_AMT) as NOR_DRW_AMT
		 , sum(ERR_DRW_AMT) as ERR_DRW_AMT
		 , min(AMT_DRW_RT)  as AMT_DRW_RT
	from BDS.ZBIL_CARD_CO_DRW_STC
	where drw_ym between '202005' and '202007'
	group by drw_ym, card_nm
	with rollup
) a
/* where drw_ym IS NOT NULL */
/* order by drw_ym, card_cd */
;

SELECT * FROM BDS.ZBIL_CARD_CO_DRW_STC;

	select DRW_YM
         , CARD_NM
		 , sum(DRW_REQ_CNT) as DRW_REQ_CNT 
		 , sum(NOR_DRW_CNT) as NOR_DRW_CNT
		 , sum(ERR_DRW_CNT) as ERR_DRW_CNT
		 , sum(DRW_REQ_AMT) as DRW_REQ_AMT
		 , sum(NOR_DRW_AMT) as NOR_DRW_AMT
		 , sum(ERR_DRW_AMT) as ERR_DRW_AMT
		 , min(AMT_DRW_RT)  as AMT_DRW_RT
	from BDS.ZBIL_CARD_CO_DRW_STC
	where drw_ym between '202005' and '202007'
	group by drw_ym, card_nm
	with rollup
