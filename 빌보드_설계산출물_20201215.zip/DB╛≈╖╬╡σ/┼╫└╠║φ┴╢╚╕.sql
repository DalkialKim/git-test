select *
from BDS.ZBIL_TS_DRW_STC
WHERE DRW_YM='202012'
order by 1,2,3
;

delete
from BDS.ZBIL_TS_DRW_STC
WHERE DRW_YM='202004'
;

rollback;
commit;

select *
from BDS.ZBIL_CHNL_TS_REQ_STC
WHERE REQ_YM='202012'
;

select *
from BDS.ZBIL_CARD_CO_DRW_STC
WHERE DRW_YM='202012'
order by 1,2,3
;

select *
from BDS.ZBIL_DRW_ERR_TYP_STC
WHERE DRW_YM='202012'
order by 1,2,4
;

select *
from BDS.ZBIL_TS_DRW_ERR_CONT_STC
WHERE DRW_YM='202012'
order by 1,2,4
;




