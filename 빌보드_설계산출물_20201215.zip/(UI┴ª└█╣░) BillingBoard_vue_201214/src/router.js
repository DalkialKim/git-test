import Vue from "vue";
import VueRouter from "vue-router";
import AppHeader from "./layout/appHeader";
import AppFooter from "./layout/appFooter";
import ProjectList from "./views/ProjectList";

import DashBoard from "./views/DashBoard";
import DataAnalysis from "./views/DataAnalysis";
import Components from "./views/Components";

import Da001 from "./views/DA-001";
import Da002 from "./views/DA-002";
import Da003 from "./views/DA-003";
import Da004 from "./views/DA-004";
import Da004Pop from "./views/DA-004-pop";
import Da005 from "./views/DA-005";
import Da006 from "./views/DA-006";
import Da007 from "./views/DA-007";
import Da008 from "./views/DA-008";
import Da009 from "./views/DA-009";
import Da010 from "./views/DA-010";
import Da011 from "./views/DA-011";
import Da012 from "./views/DA-012";
import Da013 from "./views/DA-013";
import Da014 from "./views/DA-014";
import Da015 from "./views/DA-015";

import Db001 from "./views/DB-001";
import Db003 from "./views/DB-003";
import Db004 from "./views/DB-004";

Vue.use(VueRouter);

const router = new VueRouter({
  mode: "history",
  linkExactActiveClass: "active",
  routes: [{
      path: "/",
      components: {
        //header: Header,
        projectlist: ProjectList,
      }
    },{
      path: "/DashBoard",
      components: {
        appheader: AppHeader,
        appcont: DashBoard,
        appfooter: AppFooter,
      }
    },{
      path: "/DataAnalysis",
      components: {
        appheader: AppHeader,
        appcont: DataAnalysis,
        appfooter: AppFooter,
      }
    },{
      path: "/Components",
      components: {
        appheader: AppHeader,
        appcont: Components,
        appfooter: AppFooter,
      }
    },{
      path: "/DA001",
      components: {
        appheader: AppHeader,
        appcont: Da001,
        appfooter: AppFooter,
      }
    },{
      path: "/DA002",
      components: {
        appheader: AppHeader,
        appcont: Da002,
        appfooter: AppFooter,
      }
    },{
      path: "/DA003",
      components: {
        appheader: AppHeader,
        appcont: Da003,
        appfooter: AppFooter,
      }
    },{
      path: "/DA004",
      components: {
        appheader: AppHeader,
        appcont: Da004,
        appfooter: AppFooter,
      }
    },{
      path: "/DA004POP",
      components: {
        //appheader: AppHeader,
        appcont: Da004Pop,
        //appfooter: AppFooter,
      },
    },{
      path: "/DA005",
      components: {
        appheader: AppHeader,
        appcont: Da005,
        appfooter: AppFooter,
      }
    },{
      path: "/DA006",
      components: {
        appheader: AppHeader,
        appcont: Da006,
        appfooter: AppFooter,
      }
    },{
      path: "/DA007",
      components: {
        appheader: AppHeader,
        appcont: Da007,
        appfooter: AppFooter,
      }
    },{
      path: "/DA008",
      components: {
        appheader: AppHeader,
        appcont: Da008,
        appfooter: AppFooter,
      }
    },{
      path: "/DA009",
      components: {
        appheader: AppHeader,
        appcont: Da009,
        appfooter: AppFooter,
      }
    },{
      path: "/DA010",
      components: {
        appheader: AppHeader,
        appcont: Da010,
        appfooter: AppFooter,
      }
    },{
      path: "/DA011",
      components: {
        appheader: AppHeader,
        appcont: Da011,
        appfooter: AppFooter,
      }
    },{
      path: "/DA012",
      components: {
        appheader: AppHeader,
        appcont: Da012,
        appfooter: AppFooter,
      }
    },{
      path: "/DA013",
      components: {
        appheader: AppHeader,
        appcont: Da013,
        appfooter: AppFooter,
      }
    },{
      path: "/DA014",
      components: {
        appheader: AppHeader,
        appcont: Da014,
        appfooter: AppFooter,
      }
    },{
      path: "/DA015",
      components: {
        appheader: AppHeader,
        appcont: Da015,
        appfooter: AppFooter,
      }
    },{
      path: "/DB001",
      components: {
        appheader: AppHeader,
        appcont: Db001,
        appfooter: AppFooter,
      }
    },{
      path: "/DB003",
      components: {
        appheader: AppHeader,
        appcont: Db003,
        appfooter: AppFooter,
      }
    },{
      path: "/DB004",
      components: {
        appheader: AppHeader,
        appcont: Db004,
        appfooter: AppFooter,
      }
    }
  ]
});

export default router;