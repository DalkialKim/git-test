<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">회차별 인출오류 지속여부 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출오류 분석</li>
                    <li>회차별 인출오류 지속여부 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>인출월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>카드사</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                    <option>삼성카드</option>
                                    <option>신한카드</option>
                                    <option>롯데카드</option>
                                    <option>현대카드</option>
                                    <option>BC카드</option>
                                    <option>국민카드</option>
                                    <option>하나카드(구외환)</option>
                                    <option>씨티카드</option>
                                    <option>NH카드</option>
                                    <option>하나카드</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>오류유형</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl fs t-ct">
                <!-- <colgroup>
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                    <col style="width:8%">
                </colgroup> -->
                <thead>
                    <tr>
                        <th>카드사명</th>
                        <th>표준오류명</th>
                        <th>1회차전체건수</th>
                        <th>1회차전체오류금액</th>
                        <th>1-2회차<br>인출건수</th>
                        <th>1-2회차<br>재발건수</th>
                        <th>1-2회차<br>재발율</th>
                        <th>1-2회차<br>재발오류금액</th>
                        <th>1-3회차<br>재발건수</th>
                        <th>1-3회차<br>인출건수</th>
                        <th>1-3회차<br>재발율</th>
                        <th>1-3회차<br>재발오류금액</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>신한카드</td>
                        <td>거래정지회원</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                    </tr>
                    <tr>
                        <td>신한카드</td>
                        <td>거래정지회원</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                    </tr>
                    <tr>
                        <td>신한카드</td>
                        <td>거래정지회원</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                    </tr>
                    <tr>
                        <td>신한카드</td>
                        <td>거래정지회원</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                        <td>999,999,999</td>
                    </tr>
                </tbody>
            </table>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA009",
    components: {
       appLnbMenu,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                        fill: false,
                        borderColor: "#5d607d",
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>