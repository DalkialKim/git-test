<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">카드사별 신청오류 유형별 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 신청오류 분석</li>
                    <li>카드사별 신청오류 유형별 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>신청월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:12%">
                    <col>
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                    w<col style="width:6.5%">
                </colgroup>
                <thead>
                    <tr>
                        <th>카드사</th>
                        <th>오류유형</th>
                        <th>1월</th>
                        <th>2월</th>
                        <th>3월</th>
                        <th>4월</th>
                        <th>5월</th>
                        <th>6월</th>
                        <th>7월</th>
                        <th>8월</th>
                        <th>9월</th>
                        <th>10월</th>
                        <th>11월</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="t-bold" rowspan="8">BC카드</td>
                        <td class="t-lt">카드사확인필요</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드사용불가(미등록/도난/분실)</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드번호불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">유효기간불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">생년월일불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">비밀번호오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">기타오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr class="total">
                        <td>합계</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-bold" rowspan="8">NH카드</td>
                        <td class="t-lt">카드사확인필요</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드사용불가(미등록/도난/분실)</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드번호불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">유효기간불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">생년월일불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">비밀번호오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">기타오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr class="total">
                        <td>합계</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-bold" rowspan="8">국민카드</td>
                        <td class="t-lt">카드사확인필요</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드사용불가(미등록/도난/분실)</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">카드번호불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">유효기간불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">생년월일불일치</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">비밀번호오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr>
                        <td class="t-lt b-lt">기타오류</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                    <tr class="total">
                        <td>합계</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2">합계</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                        <td>99</td>
                    </tr>
                </tfoot>
            </table>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA010",
    components: {
       appLnbMenu,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                        fill: false,
                        borderColor: "#5d607d",
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>