<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">회차별 인출현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출 분석</li>
                    <li>회차별 인출현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>인출월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:90px">
                    <col style="width:80px">
                    <col style="width:80px">
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                </colgroup>
                <thead>
                    <tr>
                        <th>인출월</th>
                        <th>회차</th>
                        <th>요청회차</th>
                        <th>회차별요청건수</th>
                        <th>회차별요청금액</th>
                        <th>정상인출건수</th>
                        <th>미인출건수</th>
                        <th>건수인출율(%)<br>(회차별)</th>
                        <th>건수인출율(%)<br>(전체)</th>
                        <th>정상인출금액</th>
                        <th>금액인출율(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="t-bold" rowspan="10">202004</td>
                        <td class="t-bold" rowspan="3">1</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">2</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">3</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt t-bold" rowspan="2">2</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">2</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt t-bold">3</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total">
                        <td colspan="2">합계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="t-bold" rowspan="10">202005</td>
                        <td class="t-bold" rowspan="3">1</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">2</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">3</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt t-bold" rowspan="2">2</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt">2</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr>
                        <td class="b-lt t-bold">3</td>
                        <td>1</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total org">
                        <td colspan="2">소계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                    <tr class="total">
                        <td colspan="2">합계</td>
                        <td>4,378,866</td>
                        <td>315,297,597,699</td>
                        <td>4,251,859</td>
                        <td>127,007</td>
                        <td>97.1</td>
                        <td>97.1</td>
                        <td>300,132,220,459</td>
                        <td>95.2</td>
                    </tr>
                </tbody>
            </table>

            <section class="chart-wrap">
                <article style="width:33.33%;">
                    <div class="chart-area" >
                        <h3>20년 05월 회차별 인출현황 - 1회차 (11일)</h3>
                        <div class="chart-cont">
                            <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                        </div>
                    </div>
                </article>
                <article style="width:33.33%;">
                    <div class="chart-area" >
                        <h3>20년 05월 회차별 인출현황 - 2회차 (18일)</h3>
                        <div class="chart-cont">
                            <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                        </div>
                    </div>
                </article>
                <article style="width:33.33%;">
                    <div class="chart-area" >
                        <h3>20년 05월 회차별 인출현황 - 3회차 (26일)</h3>
                        <div class="chart-cont">
                            <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                        </div>
                    </div>
                </article>
            </section>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartBar from "./components/ChartBar.js";

export default {
    name: "DA011",
    components: {
       appLnbMenu,
       ChartBar,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>