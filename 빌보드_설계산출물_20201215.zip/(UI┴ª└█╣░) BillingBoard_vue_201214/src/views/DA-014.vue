<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">인출오류 유형별 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출오류 분석</li>
                    <li>인출오류 유형별 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>인출월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>카드사</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                    <option>삼성카드</option>
                                    <option>신한카드</option>
                                    <option>롯데카드</option>
                                    <option>현대카드</option>
                                    <option>BC카드</option>
                                    <option>국민카드</option>
                                    <option>하나카드(구외환)</option>
                                    <option>씨티카드</option>
                                    <option>NH카드</option>
                                    <option>하나카드</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>오류유형</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:180px">
                    <col>
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                </colgroup>
                <thead>
                    <tr>
                        <th>카드사</th>
                        <th>오류유형</th>
                        <th>20년 2월</th>
                        <th>20년 3월</th>
                        <th>20년 4월</th>
                        <th>20년 5월</th>
                        <th>20년 6월</th>
                        <th>20년 7월</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="t-bold" rowspan="6">BC카드</td>
                        <td class="t-bold t-lt">거래정지회원</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">미등록카드정보</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">분실도난카드</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">유효기간오류</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">카드사문의요망</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr class="total org">
                        <td>소계</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold" rowspan="6">국민카드</td>
                        <td class="t-bold t-lt">거래정지회원</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">미등록카드정보</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">분실도난카드</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">유효기간오류</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt t-lt">카드사문의요망</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                    <tr class="total org">
                        <td>소계</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2">합계</td>
                        <td>18,111</td>
                        <td>18,340</td>
                        <td>17,266</td>
                        <td>16,965</td>
                        <td>16,556</td>
                        <td>15,981</td>
                    </tr>
                </tfoot>
            </table>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA014",
    components: {
       appLnbMenu,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                        fill: false,
                        borderColor: "#5d607d",
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>