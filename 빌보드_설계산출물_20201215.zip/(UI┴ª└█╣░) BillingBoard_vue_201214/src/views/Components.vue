<template>
    <div class="container">
        <h1>Components</h1>
        <br>

        <button-elements></button-elements>
        <databind></databind>
        <datepiker></datepiker>
        <chart></chart>

    </div>
</template>

<script>
import ButtonElements from "./components/ButtonElements";
import Databind from "./components/Databind";
import Datepiker from "./components/Datepiker";
import Chart from "./components/Chart";

export default {
    name: "components",
    components: {
       ButtonElements,
       Databind,
       Datepiker,
       Chart,
    }
};
</script>
