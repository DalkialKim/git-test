<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">채널별 회차 신청/변경 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출 분석</li>
                    <li>채널별 회차 신청/변경 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>전환월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <div class="layout">
                <div class="lt" style="width:70%">
                    <table class="tbl t-ct">
                        <colgroup>
                            <col>
                            <col style="width:22%">
                            <col style="width:22%">
                            <col style="width:22%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>신청채널</th>
                                <th>회차</th>
                                <th>신규/변경</th>
                                <th>신청건수</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-bold" rowspan="6">1-1. SWING 신규가입 (고객센터)</td>
                                <td rowspan="2">1</td>
                                <td>신규</td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">변경</td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt" rowspan="2">2</td>
                                <td>신규</td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">변경</td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit" rowspan="2">3</td>
                                <td class="hit">신규</td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">변경</td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">1-2. SWING 신규가입 (대리점)</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">2-1. SWING 신 변해 (대리점)</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">2-2. SWING 신 변해 (고객센터)</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">4. 모바일티월드</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">5. 티월드</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                            <tr>
                                <td class="t-bold" rowspan="3">카드변경내역정보반영</td>
                                <td>1</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">2</td>
                                <td></td>
                                <td>999</td>
                            </tr>
                            <tr>
                                <td class="b-lt hit">3</td>
                                <td class="hit"></td>
                                <td class="hit">999</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="rt" style="width:30%">
                    <div class="chart-area">
                        <h3>채널별 회차 신청/변경 현황</h3>
                        <div class="chart-cont">
                            <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartBar from "./components/ChartBar.js";

export default {
    name: "DA012",
    components: {
       appLnbMenu,
       ChartBar,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>