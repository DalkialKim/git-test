<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content">
            DataAnalysis
        </div>

    </div>
</template>

<script>
import appLnbMenu from "../layout/appLnbMenu";
export default {
    name: "DataAnalysis",
    components: {
       appLnbMenu,
    }
};
</script>