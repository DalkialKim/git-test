<template>
    <div class="pop-wrap" style="width:1100px;"> <!-- 개발 적용후 style="width:1000px;" 삭제 -->
        <div class="pop-head">
            <h2>이탈고객현황(계좌이체) 상세</h2>
        </div>
        <div class="pop-cont">
            <div class="scroll-y">
                <table class="tbl fs t-ct" style="width:2000px;">
                    <!-- <colgroup>
                        <col>
                    </colgroup> -->
                    <thead>
                        <tr>
                            <th width="100">신청월</th>
                            <th width="120">계정번호</th>
                            <th width="160">카드번호</th>
                            <th width="80">연령대</th>
                            <th width="120">신청채널</th>
                            <th width="120">직전납부방법</th>
                            <th width="130">은행자동납부신청여부</th>
                            <th width="80">유지기간</th>
                            <th>총수납액</th>
                            <th>6개월전계좌수납금액</th>
                            <th>5개월전계좌수납금액</th>
                            <th>4개월전계좌수납금액</th>
                            <th>3개월전계좌수납금액</th>
                            <th>2개월전계좌수납금액</th>
                            <th>1개월전계좌수납금액</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>202004</td>
                            <td>6123456789</td>
                            <td>1234-5678-1234-5678</td>
                            <td>10대</td>
                            <td>티월드</td>
                            <td>입금전용계좌</td>
                            <td>Y</td>
                            <td>12</td>
                            <td>600,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                        </tr>
                        <tr>
                            <td>202004</td>
                            <td>6123456789</td>
                            <td>1234-5678-1234-5678</td>
                            <td>10대</td>
                            <td>티월드</td>
                            <td>입금전용계좌</td>
                            <td>Y</td>
                            <td>12</td>
                            <td>600,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                        </tr>
                        <tr>
                            <td>202004</td>
                            <td>6123456789</td>
                            <td>1234-5678-1234-5678</td>
                            <td>10대</td>
                            <td>티월드</td>
                            <td>입금전용계좌</td>
                            <td>Y</td>
                            <td>12</td>
                            <td>600,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                        </tr>
                        <tr>
                            <td>202004</td>
                            <td>6123456789</td>
                            <td>1234-5678-1234-5678</td>
                            <td>10대</td>
                            <td>티월드</td>
                            <td>입금전용계좌</td>
                            <td>Y</td>
                            <td>12</td>
                            <td>600,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                        </tr>
                        <tr>
                            <td>202004</td>
                            <td>6123456789</td>
                            <td>1234-5678-1234-5678</td>
                            <td>10대</td>
                            <td>티월드</td>
                            <td>입금전용계좌</td>
                            <td>Y</td>
                            <td>12</td>
                            <td>600,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                            <td>100,000</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    components: {
    },
};
</script>

