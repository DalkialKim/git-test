<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">월별납부현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>월별납부현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>수납월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct hd-line">
                <thead>
                    <tr>
                        <th class="hc">구분</th>
                        <th class="hc" colspan="2">카드자동납부 청구</th>
                        <th class="hc" colspan="4">카드자동납부 수납</th>
                        <th class="hc" colspan="5">타납부방법 or 즉시납부</th>
                    </tr>
                    <tr>
                        <th>수납월</th>
                        <th>건수</th>
                        <th>전체금액</th>
                        <th>수납건수</th>
                        <th>비중(건수)</th>
                        <th>수납금액</th>
                        <th>비중(금액)</th>
                        <th>결제수단</th>
                        <th>수납건수</th>
                        <th>비중(건수)</th>
                        <th>수납금액</th>
                        <th>비중(금액)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td rowspan="10">202005</td>
                        <td rowspan="10" class="b-lt-b">1,000,000</td>
                        <td rowspan="10">61,968,498,322</td>
                        <td rowspan="10" class="b-lt-b">95,994</td>
                        <td rowspan="10">94.33%</td>
                        <td rowspan="10">38,361,947,764</td>
                        <td rowspan="10">98.73%</td>
                        <td class="b-lt-b">카드</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td class="cr-r">입금전용계좌</td>
                        <td class="cr-r">1,925</td>
                        <td rowspan="3" class="cr-r">1.89%</td>
                        <td class="cr-r">270,994,228</td>
                        <td rowspan="3" class="cr-r">0.70%</td>
                    </tr>
                    <tr>
                        <td class="cr-r">현금</td>
                        <td class="cr-r">1,925</td>
                        <td class="cr-r">270,994,228</td>
                    </tr>
                    <tr>
                        <td class="cr-r">계좌이체</td>
                        <td class="cr-r">1,925</td>
                        <td class="cr-r">270,994,228</td>
                    </tr>
                    <tr>
                        <td>대체</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td>SKpay 카드</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td>OK캐쉬백</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td>SK상품권</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td>SKpay 계좌이체</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                    <tr>
                        <td>지로</td>
                        <td>1,925</td>
                        <td>1.89%</td>
                        <td>270,994,228</td>
                        <td>0.70%</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>합계</td>
                        <td>1,000,000</td>
                        <td>61,968,498,322</td>
                        <td>95,994</td>
                        <td>94.33%</td>
                        <td>38,361,947,764</td>
                        <td>98.73%</td>
                        <td></td>
                        <td>5,772</td>
                        <td>5.67%</td>
                        <td>491,640,374</td>
                        <td>1.27%</td>
                    </tr>
                </tfoot>
            </table>

            <section class="chart-wrap">
                <article style="width:30%;">
                    <div class="chart-area" >
                        <h3>카드자동납부 외 수납 비중</h3>
                        <div class="chart-cont">
                            <chart-pie :data="chartData" :options="chartOptions"></chart-pie>
                        </div>
                    </div>
                </article>
            </section>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartPie from "./components/ChartPie.js";

export default {
    name: "DA001",
    components: {
       appLnbMenu,
       ChartPie,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>
