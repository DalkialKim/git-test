<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">채널별 계좌전환현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>채널별 계좌전환현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>전환월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>                        
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <div class="layout">
                <div class="lt" style="width:70%">
                    <table class="tbl">
                        <colgroup>
                            <col style="width:14%">
                            <col>
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>월</th>
                                <th>구분</th>
                                <th>채널</th>
                                <th>전환모수</th>
                                <th>전환수</th>
                                <th>전환율</th>
                                <th>유지율</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-bold t-ct" rowspan="13">10월</td>
                                <td class="t-ct b-lt-b b-bm" rowspan="4">프로모션 대상</td>
                                <td class="b-lt-b">모바일티월드</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>티월드</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>IVR</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td class="b-bm">대리점</td>
                                <td class="t-rt b-bm">23,846</td>
                                <td class="t-rt b-bm">2,779</td>
                                <td class="t-rt b-bm">11.7</td>
                                <td class="t-rt b-bm">69.8</td>
                            </tr>
                            <tr>
                                <td class="t-ct" rowspan="9">프로모션 비대상</td>
                                <td class="b-lt-b">모바일티월드</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>티월드</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>IVR</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>대리점</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>고객센터</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>은행</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>Finnq</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>SKPay통장</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                            <tr>
                                <td>네이버통장</td>
                                <td class="t-rt">23,846</td>
                                <td class="t-rt">2,779</td>
                                <td class="t-rt">11.7</td>
                                <td class="t-rt">69.8</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="rt" style="width:30%">
                    <div class="chart-area">
                        <h3>채널별/월별 전환 수</h3>
                        <div class="chart-cont">
                            <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartBar from "./components/ChartBar.js";

export default {
    name: "DA003",
    components: {
       appLnbMenu,
       ChartBar,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>