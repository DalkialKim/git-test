<template>
    <header class="header">
        <div class="inner">
            <div class="logo">
                <h1>Billing Board</h1>
            </div>
            <ul class="category-menu">
                <li><router-link to="DB001">DashBoard</router-link></li>
                <li><router-link to="DA001">Data Analysis</router-link></li>
            </ul>
            <div class="user-menu">
                <span class="user"><i class="ri-user-line"></i> IT혁신<strong>홍길동</strong>님</span>
                <button type="button"><i class="ri-logout-box-r-line"></i></button>
            </div>
        </div>
    </header>
</template>

<script>
export default {
    name: "appheader",
};
</script>

<style>
.header { 
    width:100%;
    border-bottom:1px solid #d6d5e5;
    position:fixed;    
    top:0;
    left:0;
    z-index:99;
    background:#fff;
    box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.1);
}
.header .inner {
    position:relative;
    width:1600px;
    margin:0 auto;
    transition: all .5s;
}
.wrap.wide .header .inner  {
    width:100%;
}
.logo {
    float:left;
    width:220px;
    text-align:center;
}
.logo h1 {
    display:inline-block;
    height:50px;
    line-height:50px;
    font-size:16px;
    color:#222;
    padding-left:32px;
    background:url('../assets/images/common/logo.png') no-repeat 0 50%;
    background-size:24px auto;
}
.category-menu {
    overflow:hidden;
    position:absolute;
    top:0;
    left:220px;;
}
.category-menu li {
    float:left;
    padding:0 20px;
    position:relative;
}
.category-menu li:first-child:after {
    content:"";
    width:1px;
    height:14px;
    background:#ddd;
    position:absolute;
    top:50%;
    right:0;
    margin-top:-7px;
}
.category-menu li a {
    display:block;
    line-height:50px;
    font-size:16px;
    font-weight:bold;
    color:#242330;
}
.category-menu li a:hover {
    opacity:.5;
}
.category-menu li a.active {    
    color:#ea002c;
    position:relative;
    opacity:1;
}
.category-menu li a.active:after {
    content:"";
    width:100%;
    height:3px;
    position:absolute;
    bottom:0;
    left:0;
    background:#ea002c;    
}
.user-menu {
    position:absolute;
    top:0;
    right:0;
    line-height:50px;
}
.user-menu span {
    display:inline-block;
    line-height:50px;
    font-size:13px;
    color:#666;
    padding:0 35px;
    border-left:1px solid #d9d8e9;
    vertical-align:top;
}
.user-menu span strong {
    font-size:13px;
    color:#000;
    padding:0 5px;
}
.user-menu span i {
    font-size:16px;
    color:#7e87a2;
    vertical-align:middle;
}
.user-menu button { 
    vertical-align:top;
    width:50px;
    height:50px;
    border:0;
    border-left:1px solid #d9d8e9;
    border-right:1px solid #d9d8e9;
}
.user-menu button i {
    font-size:16px;
    color:#7e87a2;
    vertical-align:middle;
}
.user-menu button:hover {
    background:#f9f9f9;
}
</style>