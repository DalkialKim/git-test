<template>
    <div class="lnb-area">
        <ul class="lnb-menu">
            <li class="plus-icon on">
                <router-link to="">카드자동납 <strong>고객</strong> 분석</router-link>
                <ul class="lnb-menu-sub" style="display:block;">
                    <li class="active"><router-link to="DA001">월별 납부 현황</router-link></li>
                    <li><router-link to="DA002">채널별 계좌 납부 현황</router-link></li>
                    <li><router-link to="DA003">채널별 계좌 전환 현황</router-link></li>
                    <li><router-link to="DA004">이탈고객현황(계좌이체)</router-link></li>
                    <li><router-link to="DA005">이탈고객현황(현금)</router-link></li>
                    <li><router-link to="DA006">이탈고객현황(입금전용계좌)</router-link></li>
                </ul>
            </li>
            <li class="plus-icon">
                <router-link to="">카드자동납 <strong>신청</strong> 분석</router-link>
                <ul class="lnb-menu-sub">
                    <li><router-link to="DA007">월별 신청/해지 현황</router-link></li>
                    <li><router-link to="DA008">채널별 신청/해지 현황</router-link></li>
                    <li><router-link to="DA009">기관별 신청/해지 현황</router-link></li>
                </ul>
            </li>
            <li class="plus-icon">
                <router-link to="">카드자동납 <strong>신청오류</strong> 분석</router-link>
                <ul class="lnb-menu-sub">
                    <li><router-link to="DA010">카드사별 신청 오류 유형별 현황</router-link></li>
                </ul>
            </li>
            <li class="plus-icon">
                <router-link to="">카드자동납 <strong>인출</strong> 분석</router-link>
                <ul class="lnb-menu-sub">
                    <li><router-link to="DA011">회차별 인출 현황</router-link></li>
                    <li><router-link to="DA012">채녈별 회차 신청/변경 현황</router-link></li>
                </ul>
            </li>
            <li class="plus-icon">
                <router-link to="">카드자동납 <strong>인출오류</strong> 분석</router-link>
                <ul class="lnb-menu-sub">
                    <li><router-link to="DA013">카드사별 인출오류 현황</router-link></li>
                    <li><router-link to="DA014">인출오류 유형별 현황</router-link></li>
                    <li><router-link to="DA015">회차별 인출오류 지속여부 현황</router-link></li>
                </ul>
            </li>
        </ul>
    </div>
</template>

<script>
import $ from 'jquery';

export default {
    mounted() {
        $('.lnb-menu > li > a').click(function(){
            $('.lnb-menu > li').removeClass('on');
            $('.lnb-menu > li > a').siblings('ul').stop().slideUp(200);
            $(this).parent('li').addClass('on');
            $(this).siblings('ul').stop().slideDown(200);   
        });
    }
};
</script>

<style>
.lnb-area {
    width:220px;
    background:#424159;
    position:fixed;
    left: calc(50% + 0);
    top:50px;
    bottom:0;
    overflow:auto;
    z-index:8888;
}
.wrap.wide .lnb-area {
    left: calc(0% + 0);
}
.lnb-menu > li {
    border-bottom:1px solid #595978;
    position:relative;
}
.lnb-menu > li.on {
    background:#242330;
}
.lnb-menu > li > a {
    display:block;
    line-height:50px;
    font-size:14px;
    color:#b3b3bc;
    padding-left:20px;
}
.lnb-menu > li > a:hover {
    opacity:.6;
}
.lnb-menu > li > a > strong {
    font-weight:500;
    color:#e7e7f1;
}
.lnb-menu > li.plus-icon:after {
    content:"";
    width:12px;
    height:12px;
    position:absolute;
    top:19px;
    right:10px;
    background:url('../assets/images/common/icon-plus.png') no-repeat 50%;
    background-size:12px auto;
    transition: all .4s;
}
.lnb-menu > li.plus-icon.on:after { 
    background:url('../assets/images/common/icon-minus.png') no-repeat 50%;
    background-size:12px auto;
    transform: rotate(180deg);
}
.lnb-menu-sub { 
    display:none;
    background:#37374b;
    border-top:1px solid #595978;
}
.lnb-menu-sub > li > a  {
    display:block;
    line-height:34px;
    font-size:13px;
    color:#c2c6d8;
    padding-left:20px;
}
.lnb-menu-sub > li.active { 
    background:#5f5e7e;
    color:#fff;
}
.lnb-menu-sub > li.active > a { 
    color:#fff;
}
.lnb-menu-sub > li > a:hover {
    opacity:.6;
}
</style>