import Vue from 'vue'
import App from './App.vue'
import router from './router'
import 'remixicon/fonts/remixicon.css'
import './assets/css/animate.css'
import './assets/css/reset.css'
import './assets/css/common.css'

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')