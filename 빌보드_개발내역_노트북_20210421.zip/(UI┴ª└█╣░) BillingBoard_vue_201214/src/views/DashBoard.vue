<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content">
            DashBoard
        </div>

    </div>
</template>

<script>
import appLnbMenu from "../layout/appLnbMenu";
export default {
    name: "DashBoard",
    components: {
       appLnbMenu,
    }
};
</script>