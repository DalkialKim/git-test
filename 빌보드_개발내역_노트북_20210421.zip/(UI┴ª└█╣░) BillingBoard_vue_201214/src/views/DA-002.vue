<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">채널별 계좌납부현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>채널별 계좌납부현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>수납월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl">
                <colgroup>
                    <col style="width:14%">
                    <col>
                    <col style="width:14%">
                    <col style="width:14%">
                    <col style="width:14%">
                    <col style="width:14%">
                    <col style="width:14%">
                </colgroup>
                <thead>
                    <tr>
                        <th>수납월</th>
                        <th>채널</th>
                        <th>결제수단</th>
                        <th>수납건수</th>
                        <th>비중(건수)</th>
                        <th>수납금액</th>
                        <th>비중(금액)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="t-bold t-ct" rowspan="9">202011</td>
                        <td>입금전용계좌</td>
                        <td>입금전용계좌</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">모바일T월드</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">모바일T월드</td>
                        <td>SKpay 계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">IVR(상담-고객)</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">IVR(Self)</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">IVR(상담-미납)</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">Bill Letter</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">T월드</td>
                        <td>계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                    <tr>
                        <td class="b-lt">창구</td>
                        <td>SKpay 계좌이체</td>
                        <td class="t-rt">999</td>
                        <td class="t-rt">99%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">99%</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td class="t-ct" colspan="3">합계</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">100%</td>
                        <td class="t-rt">9,999,999</td>
                        <td class="t-rt">100%</td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA001",
    components: {
       appLnbMenu,
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>