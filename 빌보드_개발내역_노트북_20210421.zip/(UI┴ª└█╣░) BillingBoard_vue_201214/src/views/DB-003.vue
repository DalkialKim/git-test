<template>
    <div class="container">

        <app-lnb-menu-db></app-lnb-menu-db>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">Billing Work Flow</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Dashboard</li>
                    <li>Billing Work Flow</li>
                </ul>
            </div>

            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>조회기간</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <div class="month-btn">
                                <button type="button">1월</button>
                                <button type="button">2월</button>
                                <button type="button">3월</button>
                                <button type="button">4월</button>
                                <button type="button">5월</button>
                                <button type="button">6월</button>
                                <button type="button">7월</button>
                                <button type="button">8월</button>
                                <button type="button" class="on">9월</button>
                                <button type="button">10월</button>
                                <button type="button">11월</button>
                                <button type="button">12월</button>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->
            <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <ul class="legend">
                    <li><span class="cr1">작업완료</span></li>
                    <li><span class="cr2">작업진행</span></li>
                    <li><span class="cr3">작업대기</span></li>
                </ul>
            </div>

            <div class="work-flow">
                <div class="fix-row">
                    <div class="row first"></div>
                    <div class="row num1"><span>요금</span></div>
                    <div class="row num2"><span>청구서</span></div>
                    <div class="row num3"><span>수납</span></div>
                    <div class="row num4"><span>미납</span></div>
                </div>
                <div class="scroll-tbl">
                    <table style="width:3000px;">
                        <thead>
                            <tr>
                                <th><span>1</span></th>
                                <th><span>2</span></th>
                                <th><span>3</span></th>
                                <th><span>4</span></th>
                                <th><span class="today">5</span></th>
                                <th><span class="sat">6</span></th>
                                <th><span class="sun">7</span></th>
                                <th><span>8</span></th>
                                <th><span>9</span></th>
                                <th><span>10</span></th>
                                <th><span>11</span></th>
                                <th><span>12</span></th>
                                <th><span class="sat">13</span></th>
                                <th><span class="sun">14</span></th>
                                <th><span>15</span></th>
                                <th><span>16</span></th>
                                <th><span>17</span></th>
                                <th><span>18</span></th>
                                <th><span>19</span></th>
                                <th><span class="sat">20</span></th>
                                <th><span class="sun">21</span></th>
                                <th><span>22</span></th>
                                <th><span>23</span></th>
                                <th><span>24</span></th>
                                <th><span>25</span></th>
                                <th><span>26</span></th>
                                <th><span class="sat">27</span></th>
                                <th><span class="sun">28</span></th>
                                <th><span>29</span></th>
                                <th><span>30</span></th>
                                <th><span>31</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><span class="work-item" title="텍스트가 길 경우 말줄임">텍스트가 길 경우 말줄임</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td colspan="2"><span class="work-item progress" title="마우스오버시 title 툴팁제공">마우스오버시 title 툴팁제공</span></td>                                
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr class="line">
                                <td></td>
                                <td></td>
                                <td colspan="3"><span class="work-item" title="내용02">내용02</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><span class="work-item" title="내용03">내용03</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td colspan="2"><span class="work-item waiting" title="내용04">내용04</span></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr class="line">
                                <td></td>
                                <td></td>
                                <td><span class="work-item progress" title="내용05">내용05</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td colspan="2"><span class="work-item" title="내용06">내용06</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><span class="work-item" title="내용07">내용07</span></td>
                                <td></td>
                                <td></td>
                                <td><span class="work-item progress" title="내용08">내용08</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr class="line">
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><span class="work-item waiting" title="내용09">내용09</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td colspan="3"><span class="work-item waiting" title="내용10">내용10</span></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td><span class="work-item" title="내용11">내용11</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><span class="work-item waiting" title="내용12">내용12</span></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--10-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--20-->
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td><!--30-->
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- //work-flow -->

            <section class="work-list">
                <article>
                    <div class="subtit">
                        <h3>완료작업릭스트</h3>
                        <span>전일 22시~08시</span>
                    </div>
                    <table class="work-tbl">
                        <colgroup>
                            <col style="width:20%">
                            <col>
                            <col style="width:20%">
                            <col style="width:25%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>업무</th>
                                <th>작업</th>
                                <th>상태</th>
                                <th>건수/금액</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc02">미납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc03">청구</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                        </tbody>
                    </table>
                </article>
                <article>
                    <div class="subtit">
                        <h3>주간작업리스트</h3>
                        <span>당일 08시~22시</span>
                    </div>
                    <table class="work-tbl">
                        <colgroup>
                            <col style="width:20%">
                            <col>
                            <col style="width:20%">
                            <col style="width:25%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>업무</th>
                                <th>작업</th>
                                <th>상태</th>
                                <th>건수/금액</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc02">미납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc03">청구</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                        </tbody>
                    </table>
                </article>
                <article>
                    <div class="subtit">
                        <h3>예정작업리스트</h3>
                        <span>당일 22시~08시</span>
                    </div>
                    <table class="work-tbl">
                        <colgroup>
                            <col style="width:20%">
                            <col>
                            <col style="width:20%">
                            <col style="width:25%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>업무</th>
                                <th>작업</th>
                                <th>상태</th>
                                <th>건수/금액</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc01">수납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc02">미납</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                            <tr>
                                <td class="t-ct"><strong class="fc03">청구</strong></td>
                                <td class="t-ct">카드2회차 인출</td>
                                <td class="t-ct">정상</td>
                                <td class="t-rt">23만건/233(억원)</td>
                            </tr>
                        </tbody>
                    </table>
                </article>
            </section>

        </div>

    </div>
</template>

<script>
import $ from 'jquery';
import appLnbMenuDb from "../layout/appLnbMenuDb";
export default {
    name: "DashBoard",
    components: {
       appLnbMenuDb,
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};
</script>

<style>
.work-flow {
    position:relative;
    padding-left:49px;
    border:1px solid #7e87a2;
    background:#f9f9f9;
}
.fix-row {
    position:absolute;
    top:0;
    left:0;
}
.fix-row .row {
    width:50px;
    text-align:center;
    border-bottom:1px solid #9ca3b7;
    border-right:1px solid #9ca3b7;
    display:table;
    box-sizing:border-box;
    background:#fff;    
}
.fix-row .row.first {
    height:35px;
    background:#7e87a2;
}
.fix-row .row span {
    display:table-cell;
    vertical-align:middle;
    font-size:12px;
    color:#444;
    font-weight:500;
}
.fix-row .row.num1 span {
    height:105px;
}
.fix-row .row.num2 span {
    height:104px;
}
.fix-row .row.num3 span {
    height:139px;
}
.fix-row .row.num4 span {
    height:140px;
}
.fix-row .row.num4 { 
    border-bottom:0;
}
.scroll-tbl { 
    overflow-y:auto;
}
.scroll-tbl table {
    width:100%;
    table-layout: fixed;
    overflow:hidden;
}
.scroll-tbl table thead th {
    height:35px;    
    background:#7e87a2;
    border-left:1px solid #9498c2;
}
.scroll-tbl table thead th span {
    display:inline-block;
    width:26px;
    line-height:26px;
    background:#7e87a2;
    text-align:center;
    border-radius:100%;    
    font-size:12px;
    font-weight:500;
    color:#fff;
}
.scroll-tbl table thead th span.sat {
    color:#99cbff;
}
.scroll-tbl table thead th span.sun {
    color:#ff9797;
}
.scroll-tbl table thead th span.today {
    background:#ea002c;
    position:relative;
    color:#fff;
}
.scroll-tbl table thead th span.today:after { 
    content:"";
    width:1px;
    height:1000px;
    background:#ea002c;
    position:absolute;
    left:50%;
    top:26px;
}
.scroll-tbl table tbody td {
    height:35px;
    border-left:1px solid #eee;
    border-bottom:1px solid #eee;
    box-sizing:border-box;
    padding:0 4px;
    background:#f8f9fc;
}
.scroll-tbl table tbody tr.line td {
    border-bottom:1px solid #9ca3b7;    
}
.work-item {
    display:block;
    line-height:26px;
    padding:0 10px;
    box-sizing:border-box;
    border-radius:30px;
    background:#6a6a74;
    font-size:12px;
    font-weight:100;
    color:#fff;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
    text-align:center;
    animation: animt 1s forwards;
    animation-delay: 0.1s;
    opacity: 0;
}
.work-item.progress {
    background:#f34159;
    animation-delay: 0.3s;
}
.work-item.waiting {
    background:#3fa792;
    animation-delay: 0.5s;
}
@keyframes animt {
  from {
    opacity: 0;
    width:0;
  }
  to {
    opacity: 1;
    width:100%;
  }
}
.work-list {
    margin-top:30px;
    overflow:hidden;
}
.work-list article {
    float:left;
    width:33.33%;
    box-sizing:border-box;
    padding:0 15px;
}
.work-list article:first-child {
    padding-left:0;
}
.work-list article:last-child {
    padding-right:0;
}
.subtit {
    overflow:hidden;
}
.subtit h3 {
    font-size:18px;
    color:#424159;
    font-weight:700;
    float:left;
    line-height:24px;
}
.subtit span {
    font-size:13px;
    color:#7e87a2;
    font-weight:500;
    float:right;
    line-height:24px;
}
.work-tbl {
    width:100%;
    table-layout:fixed;
    border-top:2px solid #7e87a2;
    margin-top:10px;
}
.work-tbl thead th {
    height:32px;
    border-bottom:1px solid #7e87a2;    
    font-size:12px;
    color:#7e87a2;
}
.work-tbl tbody td {
    height:32px;
    border-bottom:1px solid #eee;
    font-size:13px;
    color:#666;    
}
.work-tbl tbody td strong {
    font-size:13px;    
}
.work-tbl tbody td strong.fc01 {
    color:#444;
}
.work-tbl tbody td strong.fc02 {
    color:#ea002c;
}
.work-tbl tbody td strong.fc03 {
    color:#3fa792;
}
.work-tbl tbody td.t-ct {
    text-align:center;
}
.work-tbl tbody td.t-rt {
    text-align:right;
}
</style>