<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">이탈고객현황(입금전용계좌)</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>이탈고객현황(입금전용계좌)</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>기준월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <span class="radio-design">
                                <input type="radio" id="r1" name="r1">
                                <label for="r1">카드납신청이후</label>
                            </span>
                            <span class="radio-design">
                                <input type="radio" id="r2" name="r1">
                                <label for="r2">카드납신청이전</label>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <div class="scroll-y">
                <summary>카드납신청이후</summary><!-- 확인용 -->
                <table class="tbl fs" style="min-width:1300px;">
                    <colgroup>                        
                        <col style="width:5.8%">
                        <col>
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>신청월</th>
                            <th>채널</th>
                            <th>제휴카드</th>
                            <th>6개월고객수</th>
                            <th>6개월금액</th>
                            <th>5개월고객수</th>
                            <th>5개월금액</th>
                            <th>4개월고객수</th>
                            <th>4개월금액</th>
                            <th>3개월고객수</th>
                            <th>3개월금액</th>
                            <th>2개월고객수</th>
                            <th>2개월금액</th>
                            <th>1개월고객수</th>
                            <th>1개월금액</th>
                            <th>합계건수</th>
                            <th>합계금액</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="t-bold t-ct" rowspan="2">202004</td>
                            <td class="t-ct t-bold" rowspan="2">입금전용계좌</td>
                            <td class="t-ct">비제휴</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                        </tr>
                        <tr>
                            <td class="t-ct b-lt">제휴</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="t-ct" colspan="2">합계</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt"></td>
                        </tr>
                    </tfoot>
                </table>
                <summary>카드납신청이전</summary><!-- 확인용 -->
                <table class="tbl fs" style="min-width:1300px;">
                    <colgroup>   
                        <col>                     
                        <col style="width:5.8%">                        
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                        <col style="width:5.8%">
                    </colgroup>
                    <thead>
                        <tr>                            
                            <th>채널</th>
                            <th>제휴카드</th>
                            <th>6개월고객수</th>
                            <th>6개월금액</th>
                            <th>5개월고객수</th>
                            <th>5개월금액</th>
                            <th>4개월고객수</th>
                            <th>4개월금액</th>
                            <th>3개월고객수</th>
                            <th>3개월금액</th>
                            <th>2개월고객수</th>
                            <th>2개월금액</th>
                            <th>1개월고객수</th>
                            <th>1개월금액</th>
                            <th>합계건수</th>
                            <th>합계금액</th>
                            <th>신청월</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="t-bold t-ct" rowspan="2">입금전용계좌</td>
                            <td class="t-ct">비제휴</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-bold t-ct" rowspan="2">202004</td>
                        </tr>
                        <tr>
                            <td class="t-ct b-lt">제휴</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="t-ct" colspan="2">합계</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt">9,999,999</td>
                            <td class="t-rt"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA005",
    components: {
       appLnbMenu,
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>