<template>
    <div class="pro-list-wrap">
        <h1>Billing Board</h1>
        <ul class="worker">
            <li><span>PUBLISHER</span> <strong>박병조 과장</strong><em>|</em>010-4841-3378<em>|</em>eva01x@muplus.co.kr</li>
            <li><span>DESIGNER</span> <strong>이미경 대리</strong><em>|</em>010-5579-8920<em>|</em>tpfvm0202@muplus.co.kr</li>
        </ul>
        <table>
            <colgroup>
                <col style="width:12%"/>
                <col style="width:15%"/>
                <col style="width:15%"/>
                <col style="width:120px"/>
                <col style="width:15%"/>
                <col/>
            </colgroup>
            <thead>
                <tr>
                    <th>1Depth</th>
                    <th>2Depth</th>
                    <th>3Depth</th>                    
                    <th>pop/layer</th>
                    <th>fileName(ID)</th>
                    <th>update</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th rowspan="3">Dashboard</th>
                    <td class="t_left">Billing Cash Flow</td>
                    <td class="t_left"></td>                    
                    <td></td>
                    <td class="t_left"><a href="DB001" target='_blank' class="linktxt">DB-001.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-14</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th rowspan="2">Dashboard</th> -->
                    <td class="t_left">Billing Work Flow</td>
                    <td class="t_left"></td>                    
                    <td></td>
                    <td class="t_left"><a href="DB003" target='_blank' class="linktxt">DB-003.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Dashboard</th> -->
                    <td class="t_left">Billing Work Flow 상세</td>
                    <td class="t_left"></td>                    
                    <td></td>
                    <td class="t_left"><a href="DB004" target='_blank' class="linktxt">DB-004.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" class="hr-line"></td>
                </tr>
                <tr>
                    <th rowspan="16">Data Analysis</th>
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">월별납부현황</td>                   
                    <td></td>
                    <td class="t_left"><a href="da001" target='_blank' class="linktxt">DA-001.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-02</em>추가</li>
                            <li><em>2020-12-10</em>테이블 레이아웃 변경, 총데이터 삭제, 그래프 위치 변경 (Billing Board_v0.3_201207.pptx)</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">채널별 계좌납부현황</td>                    
                    <td></td>
                    <td class="t_left"><a href="da002" target='_blank' class="linktxt">DA-002.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-02</em>추가</li>
                            <li><em>2020-12-10</em>테이블 레이아웃 변경, 총데이터 삭제 (Billing Board_v0.3_201207.pptx)</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">채널별 계좌전환현황</td>                    
                    <td></td>
                    <td class="t_left"><a href="da003" target='_blank' class="linktxt">DA-003.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-02</em>추가</li>
                            <li><em>2020-12-10</em>테이블 레이아웃 변경, 총데이터 삭제 (Billing Board_v0.3_201207.pptx)</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">이탈고객현황(계좌이체)</td>                    
                    <td></td>
                    <td class="t_left"><a href="da004" target='_blank' class="linktxt">DA-004.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                            <li><em>2020-12-11</em>6개월고객수 합계 팝업 링크 추가(Billing Board_v0.4_201210.pptx)</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">이탈고객현황(계좌이체)</td>
                    <td>상세 popup</td>
                    <td class="t_left"><a href="da004pop" target='_blank' class="linktxt">DA-004-pop.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-14</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">이탈고객현황(현금)</td>                    
                    <td></td>
                    <td class="t_left"><a href="da005" target='_blank' class="linktxt">DA-005.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납 고객 분석</td>
                    <td class="t_left">이탈고객현황(입금전용계좌)</td>                    
                    <td></td>
                    <td class="t_left"><a href="da006" target='_blank' class="linktxt">DA-006.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 신청 분석</td>
                    <td class="t_left">월별 신청/해지 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da007" target='_blank' class="linktxt">DA-007.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-10</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 신청 분석</td>
                    <td class="t_left">채널별 신청/해지 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da008" target='_blank' class="linktxt">DA-008.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 신청 분석</td>
                    <td class="t_left">기관별 신청/해지 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da009" target='_blank' class="linktxt">DA-009.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 신청오류 분석</td>
                    <td class="t_left">카드사별 신청오류 유형별 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da010" target='_blank' class="linktxt">DA-010.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 인출 분석</td>
                    <td class="t_left">회차별인출현황</td>
                    <td></td>
                    <td class="t_left"><a href="da011" target='_blank' class="linktxt">DA-011.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 인출 분석</td>
                    <td class="t_left">채널별 회차 신청/변경 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da012" target='_blank' class="linktxt">DA-012.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 인출오류 분석</td>
                    <td class="t_left">카드사별 인출오류 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da013" target='_blank' class="linktxt">DA-013.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 인출오류 분석</td>
                    <td class="t_left">인출오류 유형별 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da014" target='_blank' class="linktxt">DA-014.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <!-- <th>Data Analysis</th> -->
                    <td class="t_left">카드자동납부 인출오류 분석</td>
                    <td class="t_left">회차별 인출오류 지속여부 현황</td>
                    <td></td>
                    <td class="t_left"><a href="da015" target='_blank' class="linktxt">DA-015.vue</a></td>
                    <td class="t_left">
                        <ul class="notelist">
                            <li><em>2020-12-11</em>추가</li>
                        </ul>
                    </td>
                </tr>
            </tbody>
        </table>

    </div>
</template>

<script>
export default {};
</script>

<style>
.pro-list-wrap { 
    width:1440px;
    margin:20px auto;
    border:1px solid #ddd;
    background:#fff;
    padding:20px;
    box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
    border-radius:10px;
    position:relative;
}
.pro-list-wrap h1 {
    font-size:35px;
}
.pro-list-wrap table { 
    width:100%;
    table-layout:fixed;
    border-top:1px solid #444;
    border-right:1px solid #ddd;
    margin-top:20px;
}
.pro-list-wrap table th {
    background:#f9f9f9;
    height:35px;
    font-size:13px;
    color:#444;
    font-weight:bold;
    border-left:1px solid #ddd;
    border-bottom:1px solid #ddd;
    padding:0 10px;
    text-align:center;
}
.pro-list-wrap table td {
    height:35px;
    font-size:13px;
    color:#666;
    border-left:1px solid #ddd;
    border-bottom:1px solid #ddd;
    padding:0 10px;
    text-align:center;
}
.pro-list-wrap table td.hr-line {
    height:2px;
}
.t_left {
    text-align:left !important;
}
.linktxt {
    color:#5693e0;
}
.worker {
    position:absolute;
    top:16px;
    right:20px;
}
.worker li {
    margin:5px 0;
    line-height:20px;
    color:#888;
}
.worker li span {
    display:inline-block;    
    padding:0 15px;
    border-radius:20px;
    background:#aaa;
    color:#fff;
    font-size:10px;
    width:50px;
    text-align:center;
    margin-right:5px;
}
.worker li strong {
    font-weight:bold;
    color:#444;
}
.worker li em {
    color:#eee;
    font-size:11px;
    padding:0 5px;
}
.notelist li {
    padding:2px 0;
    line-height:22px;
    color:#444;
    font-size:12px;
    position:relative;
    padding-left:75px;
    border-top:1px dashed #ddd;
}
.notelist li:first-child {
    border-top:0;
}
.notelist li em {
    display: inline-block;
    color: #ea002c;
    font-size: 11px;
    font-weight:700;
    position:absolute;
    top:2px;
    left:0;
}
</style>