<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">월별 신청/해지 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 신청 분석</li>
                    <li>월별 신청/해지 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>신청월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <div class="layout">
                <div class="lt" style="width:70%">
                    <table class="tbl t-ct">
                        <colgroup>
                            <col style="width:14%">
                            <col>
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                            <col style="width:14%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>수납월</th>
                                <th>카드 유형</th>
                                <th>전체 고객수</th>
                                <th>구분</th>
                                <th>당월신청</th>
                                <th>당월해지</th>
                                <th>당월증감</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td rowspan="8">202011</td>
                                <td rowspan="4">제휴</td>
                                <td rowspan="4">1,177,065</td>
                                <td>신규가입</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">신규가입</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">신규가입</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">신규가입</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt" rowspan="4">비제휴</td>
                                <td rowspan="4">1,177,065</td>
                                <td>신규가입</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">신규</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">변경(은행→카드)</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                            <tr>
                                <td class="b-lt">변경(카드→카드)</td>
                                <td>2,580</td>
                                <td>2,580</td>
                                <td>2,580</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2">합계</td>
                                <td>9,779,571</td>
                                <td></td>
                                <td>217,975</td>
                                <td>183,434</td>
                                <td>34,541</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="rt" style="width:30%">
                    <div class="chart-area">
                        <h3>월별 신청/해지 건수</h3>
                        <div class="chart-cont">
                            <chart-line :data="chartData" :options="chartOptions"></chart-line>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartLine from "./components/ChartLine.js";

export default {
    name: "DA007",
    components: {
       appLnbMenu,
       ChartLine,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                        fill: false,
                        borderColor: "#ddd",
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>