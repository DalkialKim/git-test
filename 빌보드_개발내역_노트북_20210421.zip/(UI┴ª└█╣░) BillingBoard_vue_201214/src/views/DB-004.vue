<template>
    <div class="container">

        <app-lnb-menu-db></app-lnb-menu-db>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">Billing Work Flow 상세</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Dashboard</li>
                    <li>Billing Work Flow 상세</li>
                </ul>
            </div>

            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>작업일자</label>
                            <span class="datepick-custom">
                                <input type="text" value="2020-11-10">
                                <!-- <datetime></datetime> -->
                                <i class="ri-calendar-line"></i>
                            </span>
                        </li>
                        <li>
                            <label>업무모듈</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>작업상태</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->
            <div class="tbl-top">
                <span class="tbl-total">total :<strong>999</strong></span>
            </div>

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:100px">
                    <col style="width:100px">
                    <col>
                    <col>
                    <col style="width:150px">
                    <col style="width:150px">
                    <col style="width:150px">
                    <col style="width:120px">
                    <col style="width:120px">
                    <col style="width:10%">
                </colgroup>
                <thead>
                    <tr>
                        <th>작업상태</th>
                        <th>업무</th>
                        <th>작업유형</th>
                        <th>작업상세</th>
                        <th>예정시각</th>
                        <th>시작시각</th>
                        <th>종료시각</th>
                        <th>소요시간</th>
                        <th>건수</th>
                        <th>금액</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                    <tr>
                        <td>완료</td>
                        <td>청구</td>
                        <td>무선요금계산2차</td>
                        <td>사전작업</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>2020-11-03 03:00</td>
                        <td>1시간</td>
                        <td>99</td>
                        <td>99,999,999</td>
                    </tr>
                </tbody>
            </table>            

        </div>

    </div>
</template>

<script>
import $ from 'jquery';
import appLnbMenuDb from "../layout/appLnbMenuDb";
// import { Datetime } from 'vue-datetime'
// import 'vue-datetime/dist/vue-datetime.css'

export default {
    name: "DashBoard",
    components: {
       appLnbMenuDb,
       //Datetime
    },
    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    },
};
</script>

<style>

</style>