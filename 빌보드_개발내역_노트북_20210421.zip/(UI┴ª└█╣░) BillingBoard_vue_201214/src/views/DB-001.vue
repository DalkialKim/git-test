<template>
    <div class="container">

        <app-lnb-menu-db></app-lnb-menu-db>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">Billing Cash Flow</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Dashboard</li>
                    <li>Billing Cash Flow</li>
                </ul>
            </div>

            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>조회기간</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <div class="month-btn">
                                <button type="button">1월</button>
                                <button type="button">2월</button>
                                <button type="button">3월</button>
                                <button type="button">4월</button>
                                <button type="button">5월</button>
                                <button type="button">6월</button>
                                <button type="button">7월</button>
                                <button type="button">8월</button>
                                <button type="button" class="on">9월</button>
                                <button type="button">10월</button>
                                <button type="button">11월</button>
                                <button type="button">12월</button>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <div class="layout line">
                <div class="lt" style="width:80%">
                    <div class="titx">
                        <h3>청구 현황<span>당월 청구금액</span></h3>
                    </div>
                    <dl class="status-board">
                        <dt>
                            <div class="status-first animated fadeInUp delay-02s">
                                <span>당월 청구</span>
                                <h4>2690만건</h4>
                                <p>1.5조원</p>
                                <strong class="down">1492억원</strong>
                            </div>
                        </dt>
                        <dd>
                            <div class="status-box animated fadeInUp delay-03s">
                                <h4>서비스유형별 현황</h4>
                                <ul class="status-list">
                                    <li class="icon01">
                                        <span>이동전화</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon02">
                                        <span>비회선</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon03">
                                        <span>유선재판매</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                </ul>
                            </div>
                        </dd>
                        <dd>
                            <div class="status-box animated fadeInUp delay-04s">
                                <h4>납부방법별 현황</h4>
                                <ul class="status-list">
                                    <li class="icon04">
                                        <span>은행자동 납부</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon05">
                                        <span>카드자동 납부</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon06">
                                        <span>지로납부</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon07">
                                        <span>입금전용계좌</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                </ul>
                            </div>
                        </dd>
                        <dd>
                            <div class="status-box animated fadeInUp delay-05s">
                                <h4>요금안내서 유형별 현황</h4>
                                <ul class="status-list">
                                    <li class="icon08">
                                        <span>Bill Letter</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon09">
                                        <span>문자</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon10">
                                        <span>우편</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                    <li class="icon11">
                                        <span>이메일</span>
                                        <p>2844만건<strong>1.5조원</strong></p>
                                    </li>
                                </ul>
                            </div>
                        </dd>
                    </dl>

                    <div class="titx st2">
                        <h3>수납 현황<span>당월 청구금액에 대한 일자별 수납 현황</span></h3>
                    </div>
                    <dl class="status-board">
                        <dt>
                            <div class="status-first st2 animated fadeInUp delay-02s">
                                <span>당월 수납</span>
                                <h4>2690만건</h4>
                                <p>1.5조원</p>
                                <strong class="up">1492억원</strong>
                            </div>
                        </dt>
                        <dd>
                            <div class="status-box chart animated fadeInUp delay-03s">
                                <chart-bar :data="chartData" :options="chartOptions"></chart-bar>
                            </div>
                        </dd>
                    </dl>
                </div>
                <div class="rt" style="width:20%;">
                    <div class="titx">
                        <h3>수납 현황</h3>
                        <span class="info-icon">
                            <p class="info-tooltip">
                                과거 미납금액 (10/1 생성 미납원부), 현재 미납(미납원부 - 미납분 수납), 추심사별 당월 수심 위임금액
                            </p>
                        </span>
                    </div>
                    <div class="unpaid animated fadeInUp delay-02s">
                        <h4>미납 원부</h4>
                        <dl class="unpaid-data">
                            <dt>
                                <strong>1234건</strong>
                                <p>2000억원</p>
                                <span class="up">1000억</span>
                            </dt>
                            <dd>
                                <span>해지 전</span>
                                <p>1000억원</p>
                                <span class="st2">해지 후</span>
                                <p>1000억원</p>
                            </dd>
                        </dl>
                    </div>
                    <div class="unpaid type2 animated fadeInUp delay-03s">
                        <h4>현재 미납</h4>
                        <dl class="unpaid-data">
                            <dt>
                                <strong>1234건</strong>
                                <p>2000억원</p>
                                <span class="down">1000억</span>
                            </dt>
                            <dd>
                                <span>해지 전</span>
                                <p>1000억원</p>
                                <span class="st2">해지 후</span>
                                <p>1000억원</p>
                            </dd>
                        </dl>
                    </div>

                    <div class="titx st2">
                        <h3>신규 추심위임 금액</h3>
                    </div>
                    <ul class="new-amount">
                        <li class="cr1 animated fadeInRight delay-03s">
                            <em>MG</em>
                            <span>MG신용정보</span>
                            <p>2844만건<strong>1.5조원</strong></p>
                        </li>
                        <li class="cr2 animated fadeInRight delay-04s">
                            <em>SGI</em>
                            <span>SGI신용정보</span>
                            <p>2844만건<strong>1.5조원</strong></p>
                        </li>
                        <li class="cr3 animated fadeInRight delay-05s">
                            <em>F&U</em>
                            <span>F&U신용정보</span>
                            <p>2844만건<strong>1.5조원</strong></p>
                        </li>
                        <li class="cr4 animated fadeInRight delay-06s">
                            <em>고려</em>
                            <span>고려신용정보</span>
                            <p>2844만건<strong>1.5조원</strong></p>
                        </li>
                        <li class="cr5 animated fadeInRight delay-07s">
                            <em>특수</em>
                            <span>특수채권</span>
                            <p>2844만건<strong>1.5조원</strong></p>
                        </li>
                    </ul>
                </div>
            </div>

        </div>

    </div>
</template>

<script>
import $ from 'jquery';
import appLnbMenuDb from "../layout/appLnbMenuDb";
import ChartBar from "./components/ChartBar.js";
// import { Datetime } from 'vue-datetime'
// import 'vue-datetime/dist/vue-datetime.css'

export default {
    name: "DashBoard",
    components: {
       appLnbMenuDb,
       ChartBar,
    },
    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ],
            }
        };
    },
    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    },
};
</script>

<style>
.layout.line .lt {
    position:relative;
    padding-right:20px;
}
.layout.line .lt:after {
    content:"";
    width:1px;
    position:absolute;
    top:45px;
    bottom:0;
    right:0;
    background:#d9d8e9;
}
.layout.line .rt { 
    padding-left:20px;
}
.titx {
    position:relative;
    height:35px;
    margin-bottom:10px;
}
.titx.st2 {
    margin-top:40px;
}
.titx h3 {
    float:left;
    font-size:24px;
    color:#242330;
    font-weight:600;
}
.titx h3 span {
    font-size:15px;
    color:#6f7e95;
    padding-left:10px;
    vertical-align: middle;
}
.status-board {
    width:100%;
    display:table;
    table-layout: fixed;
}
.status-board dt,
.status-board dd {
    display:table-cell;
    vertical-align:top;
    box-sizing:border-box;
}
.status-board dt {
    width:220px;
}
.status-board dd {
    padding-left:20px;
}
.status-first {
    height:345px;    
    background:#6b6f91 url('../assets/images/common/bg1.png') no-repeat right 0 bottom 0;
    background-size:100%;
    padding:25px;
    box-sizing:border-box;
}
.status-first.st2 { 
    background:#7d82b5 url('../assets/images/common/bg2.png') no-repeat right 0 bottom 0;
    background-size:100%;
}
.status-first span {
    display:inline-block;
    line-height:30px;
    font-size:14px;
    color:#fff;
    padding:0 25px;
    border-radius:30px;
    background:#545371;
}
.status-first h4 {
    font-size:30px;
    color:#fff;
    margin-top:40px;
}
.status-first p {
    font-size:24px;
    color:#e6e4f9;
}
.status-first strong {
    display:inline-block;
    margin-top:20px;
    font-size:18px;
    color:#fff;
    font-weight:300;
    padding-left:20px;
}
.status-first strong.down {
    background:url('../assets/images/common/arrow_down1.png') no-repeat 0 50%;
    color:#ffdcdc;
}
.status-first strong.up {
    background:url('../assets/images/common/arrow_up1.png') no-repeat 0 50%;
    color:#bbecff;
}
.status-box {
    height:345px;
    border:1px solid #8084a8;
    border-top:3px solid #5d607d;
    padding:25px;
    box-sizing:border-box;
}
.status-box h4 {
    font-size:20px;
    color:#242330;
    font-weight:600;
}
.status-box.chart {
    text-align:center;
}
.status-box.chart canvas {
    display:inline-block !important;
    height:290px !important;
    /* width:auto !important; */
}
.status-list {
    margin-top:25px;
}
.status-list li {
    padding:10px 0 10px 48px;
    position:relative;
}
.status-list li:after { 
    content:"";
    width:38px;
    height:38px;    
    border-radius:100%;
    position:absolute;
    top:10px;
    left:0;
    background-color:#eee;
    background-repeat:no-repeat;
    background-position:50%;
}
.status-list li.icon01:after {
    background-color:#f9b310;
    background-image:url('../assets/images/common/ic_a_01.png');    
}
.status-list li.icon02:after {
    background-color:#f34159;
    background-image:url('../assets/images/common/ic_a_02.png');    
}
.status-list li.icon03:after {
    background-color:#50b5d9;
    background-image:url('../assets/images/common/ic_a_03.png');    
}
.status-list li.icon04:after {
    background-color:#50b5d9;
    background-image:url('../assets/images/common/ic_b_01.png');    
}
.status-list li.icon05:after {
    background-color:#f9b310;
    background-image:url('../assets/images/common/ic_b_02.png');    
}
.status-list li.icon06:after {
    background-color:#f34159;
    background-image:url('../assets/images/common/ic_b_03.png');    
}
.status-list li.icon07:after {
    background-color:#3fa792;
    background-image:url('../assets/images/common/ic_b_04.png');    
}
.status-list li.icon08:after {
    background-color:#f9b310;
    background-image:url('../assets/images/common/ic_c_01.png');    
}
.status-list li.icon09:after {
    background-color:#50b5d9;
    background-image:url('../assets/images/common/ic_c_02.png');    
}
.status-list li.icon10:after {
    background-color:#3fa792;
    background-image:url('../assets/images/common/ic_c_03.png');    
}
.status-list li.icon11:after {
    background-color:#f34159;
    background-image:url('../assets/images/common/ic_c_04.png');    
}
.status-list li span {
    font-size:13px;
    color:#434159;
}
.status-list li p {
    font-size:15px;
    color:#242330;
    font-weight:600;
}
.status-list li p strong {
    font-size:15px;
    color:#6f7e95;
    padding-left:8px;
    font-weight:600;
}
.info-icon { 
    position:absolute;
    top:50%;
    right:0;
    width:20px;
    height:20px;
    margin-top:-10px;
    background:url('../assets/images/common/information-line.png') no-repeat 50%;
    cursor:pointer;
}
.info-icon:hover .info-tooltip {
    display:block;
}
.info-tooltip { 
    display:none;
    position:absolute;
    top:30px;
    right:0;
    width:250px;
    background:#424159;
    border-radius:5px;
    padding:15px;
    box-sizing:border-box;
    font-size:12px;
    color:#fff;
}
.info-tooltip:after { 
    content:"";
    position:absolute;
    top:-8px;
    right:4px;
    width: 0; 
    height: 0; 
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-bottom: 8px solid #424159;
}
.unpaid {
    border:1px solid #5d607d;
    padding:16px 25px;
    box-sizing:border-box;
    border-radius:10px;
}
.unpaid h4 {
    display:inline-block;
    line-height:30px;
    font-size:14px;
    font-weight:400;
    color:#fff;
    padding:0 20px;
    border-radius:30px;
    background:#6b6f91;    
}
.unpaid.type2 {
    border:1px solid #ea687d;
    margin-top:10px;
}
.unpaid.type2 h4 {
    background:#ea687d;    
}
.unpaid-data { 
    width:100%;
    display:table;
    table-layout: fixed;
    margin-top:10px;
}
.unpaid-data dt,
.unpaid-data dd {
    display:table-cell;
    vertical-align: top;
}
.unpaid-data dt {
    width:55%;
    border-right:1px solid #eaeaf2;
}
.unpaid-data dt strong {
    font-size:26px;
    color:#434159;
}
.unpaid-data dt p {
    font-size:18px;
    color:#666;
}
.unpaid-data dt span {
    display:inline-block;
    margin-top:10px;
    font-size:14px;
    padding-left:22px;
}
.unpaid-data dt span.up { 
    background:url('../assets/images/common/arrow_up2.png') no-repeat 0 50%;
    color:#5d69d8;
}
.unpaid-data dt span.down { 
    background:url('../assets/images/common/arrow_down2.png') no-repeat 0 50%;
    color:#f34159;
}
.unpaid-data dd {
    box-sizing: border-box;
    padding-left:20px;
}
.unpaid-data dd span {
    display:inline-block;
    font-size:12px;
    color:#999;
}
.unpaid-data dd span.st2 {
    margin-top:18px;
}
.unpaid-data dd p {
    font-size:14px;
    color:#434159;
}
.new-amount {
    margin-top:10px;
}
.new-amount li {
    position:relative;
    padding: 10px 0 10px 48px;
    position: relative;
}
.new-amount li em {
    width: 38px;
    line-height: 38px;
    text-align:center;
    border-radius: 100%;
    position: absolute;
    top: 10px;
    left: 0;
    background-color: #eee;
    font-size:11px;
    color:#fff;
}
.new-amount li.cr1 em {
    background-color: #f9b310;
}
.new-amount li.cr2 em {
    background-color: #f34159;
}
.new-amount li.cr3 em {
    background-color: #50b5d9;
}
.new-amount li.cr4 em {
    background-color: #3fa792;
}
.new-amount li.cr5 em {
    background-color: #6c7fd5;
}
.new-amount li span {
    font-size: 13px;
    color: #434159;
}
.new-amount li p {
    font-size: 15px;
    color: #242330;
    font-weight: 600;
}
.new-amount li p strong {
    font-size: 15px;
    color: #6f7e95;
    padding-left: 8px;
    font-weight: 600;
}
</style>