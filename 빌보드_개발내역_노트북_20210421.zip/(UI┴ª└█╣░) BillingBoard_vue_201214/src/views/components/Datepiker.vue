<template>
    <div>
        <input type="text" class="datapicker">
    </div>
</template>

<script>
import $ from 'jquery';
import 'jquery-ui';

export default {
     created(){
        console.log($.fn.jquery);
        console.log($.ui.version);
    },
    // mounted() {
    //     $(function(){
    //         $('#calendar').datapicker();
    //     });
    // }
};
</script>

<style>
</style>


