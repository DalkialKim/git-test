<template>
  <div class="chart-cont">
      <chart-pie :data="chartData" :options="chartOptions"></chart-pie>
  </div>
</template>

<script>
import ChartPie from "./ChartPie.js";
export default {
  name: "App",
  components: {
    ChartPie,
  },
  data() {
    return {
      chartOptions: {
        //hoverBorderWidth: 20
      },
      
      chartData: {
        //hoverBackgroundColor: "red",
        //hoverBorderWidth: 10,
        labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
        datasets: [
          {
            label: "Data One",
            backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
            data: [200, 100, 50, 40, 30, 30, 30, 30, 30, 30],            
          }
        ]
      }      
    };
  }
};
</script>

<style>
.chart-cont {
  padding:20px;
  box-sizing:border-box;
}
</style>