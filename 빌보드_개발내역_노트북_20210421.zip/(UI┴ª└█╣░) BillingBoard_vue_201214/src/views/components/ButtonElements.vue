<template>
    <div class="btn-area">
        <button type="button" class="btn">버튼</button>
    </div>
</template>

<script>
import $ from 'jquery';

export default {
    mounted() {
        $('.btn').click(function() {
            $(this).toggleClass('on');
        });
    }
};
</script>

<style>
.btn-area {
    border:1px solid #ddd;
    padding:30px;
}
.btn {     
    font-size:14px;
    font-weight:bold;
    color:#fff;
    height:30px;
    padding:0 15px;
    border-radius:4px;
    background:#666;
}
.btn.on {
    background:red;
}
</style>
