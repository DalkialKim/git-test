<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">카드사별 인출오류 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출오류 분석</li>
                    <li>카드사별 인출오류 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>인출월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>카드사</label>
                            <span class="select-custom">
                                <select>
                                    <option>전체</option>
                                    <option>삼성카드</option>
                                    <option>신한카드</option>
                                    <option>롯데카드</option>
                                    <option>현대카드</option>
                                    <option>BC카드</option>
                                    <option>국민카드</option>
                                    <option>하나카드(구외환)</option>
                                    <option>씨티카드</option>
                                    <option>NH카드</option>
                                    <option>하나카드</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:120px;">
                    <col style="width:180px;">
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                    <col>
                </colgroup>
                <thead>
                    <tr>
                        <th>인출월</th>
                        <th>카드사명</th>
                        <th>인출요청건수</th>
                        <th>인출건수</th>
                        <th>미인출건수</th>
                        <th>인출요청금액</th>
                        <th>인출금액</th>
                        <th>미인출금액</th>
                        <th>인출율(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="t-bold" rowspan="10">202005</td>
                        <td class="t-bold">삼성카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">신한카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">롯데카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">현대카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">BC카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">국민카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">하나카드(구외환)</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">씨티카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">NH카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                    <tr>
                        <td class="t-bold b-lt">하나카드</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2">합계</td>
                        <td>1,658,317</td>
                        <td>1,620,438</td>
                        <td>37,879</td>
                        <td>140,717,313,510</td>
                        <td>135,102,390,418</td>
                        <td>5,614,923,092</td>
                        <td>96.01</td>
                    </tr>
                </tfoot>
            </table>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA013",
    components: {
       appLnbMenu,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                        fill: false,
                        borderColor: "#5d607d",
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>