<template>
    <div id="app" class="wrap">

        <button class="floating-btn"><i class="ri-layout-5-line"></i></button>

        <router-view name="appheader"></router-view>

        <router-view name="appcont"></router-view>

        <router-view name="projectlist"></router-view>

        <!-- <router-view name="appfooter"></router-view> -->

    </div>
</template>

<script>
// export default {
//     name: "App",
// };
import $ from 'jquery';

export default {
    mounted() {
        $('.floating-btn').click(function(){
            $(this).toggleClass('on');
            $('.wrap').toggleClass('wide');  
        });
    }
};
</script>

<style>
.floating-btn {width:50px;height:50px;background:#414159;border-radius:100%;position:fixed;bottom:50px;right:50px;z-index:9999;font-size:26px;color:#fff; box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.3);}
.floating-btn i {vertical-align:-1px;}
.floating-btn.on {opacity:.3;}
</style>
