<template>
    <div class="lnb-area">
        <ul class="lnb-menu">
            <li class="on">
                <router-link to="DB001">Billing Cash Flow</router-link>
            </li>
            <li>
                <router-link to="">Billing Cash Flow 상세</router-link>
            </li>
            <li>
                <router-link to="DB003">Billing Work Flow</router-link>
            </li>
            <li>
                <router-link to="DB004">Billing Work Flow 상세</router-link>
            </li>
        </ul>
    </div>
</template>

<script>
import $ from 'jquery';

export default {
    mounted() {
        $('.lnb-menu > li').click(function(){
            $('.lnb-menu > li').removeClass('on');
            $(this).addClass('on');
        });
    }
};
</script>

<style>
.lnb-area {
    width:220px;
    background:#424159;
    position:fixed;
    left: calc(50% + 0);
    top:50px;
    bottom:0;
    /* overflow:auto; */
    z-index:8888;
}
.wrap.wide .lnb-area {
    left: calc(0% + 0);
}
.lnb-menu > li {
    border-bottom:1px solid #595978;
    position:relative;
}
.lnb-menu > li.on {
    background:#242330;
}
.lnb-menu > li > a {
    display:block;
    line-height:50px;
    font-size:14px;
    color:#b3b3bc;
    padding-left:20px;
}
.lnb-menu > li > a:hover {
    opacity:.6;
}
.lnb-menu > li > a > strong {
    font-weight:500;
    color:#e7e7f1;
}
.lnb-menu > li.plus-icon:after {
    content:"";
    width:12px;
    height:12px;
    position:absolute;
    top:19px;
    right:10px;
    background:url('../assets/images/common/icon-plus.png') no-repeat 50%;
    background-size:12px auto;
    transition: all .4s;
}
.lnb-menu > li.plus-icon.on:after { 
    background:url('../assets/images/common/icon-minus.png') no-repeat 50%;
    background-size:12px auto;
    transform: rotate(180deg);
}
.lnb-menu-sub { 
    display:none;
    background:#37374b;
    border-top:1px solid #595978;
}
.lnb-menu-sub > li > a  {
    display:block;
    line-height:34px;
    font-size:13px;
    color:#c2c6d8;
    padding-left:20px;
}
.lnb-menu-sub > li.active { 
    background:#5f5e7e;
    color:#fff;
}
.lnb-menu-sub > li.active > a { 
    color:#fff;
}
.lnb-menu-sub > li > a:hover {
    opacity:.6;
}
</style>