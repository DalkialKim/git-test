<template>
    <div class="footer">
        <div class="inner">
            <p>COPYRIGHT ⓒ sample CO., LTD. ALL RIGHTS RESERVED</p>
        </div>
    </div>
</template>

<script>
export default {
    name: "appfooter",
};
</script>

<style>
.footer {
    width:100%;
    position:fixed;
    bottom:0;
    left:0;
    background:#f9f9f9;
    border-top:1px solid #ddd;
}
.footer .inner {
    width:1280px;
    margin:0 auto;
    padding:10px 0;
}
.footer .inner p {
    font-size:12px;
    color:#999;
}
</style>