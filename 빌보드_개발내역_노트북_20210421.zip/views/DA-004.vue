<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content">
            <div class="cont-top">
                <h2 class="tit">이탈고객현황(계좌이체)</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>이탈고객현황(계좌이체)</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list" id='selectSearchStrdYm'>
                    <ul class="search-item">
                        <li>
                            <label>수납월</label>
                            <span class="select-custom">
                                <select id='selectStrdYm' @change="changeStrdYm($event)">
                                    <option value='202009'>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011' selected>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <span class="radio-design">
                                <input type="radio" id="r1" name="selectBfAfGb" value='AF' checked>
                                <label for="r1">카드납신청이후</label>
                            </span>
                            <span class="radio-design">
                                <input type="radio" id="r2" name="selectBfAfGb" value='BF'>
                                <label for="r2">카드납신청이전</label>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->
            <div class="tbl-top">
                <h3 class="tbl-tit" id='selectedStrdYm'>2020년 09월</h3>
                <span class="tbl-total" id='selectedStrdYmTotal'>total :<strong>999</strong></span>
            </div>
            <!-- //tbl-top -->
            <div class="scroll-y">
                <table class="tbl fs" style="min-width:1300px;" id="table1">
                    <template v-if="this.bfAfGb == 'AF'">
                    <colgroup>
                        <col style="width:5.4%">
                        <col style="width:6.3%">
                        <col style="width:5.7%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                        <col style="width:5.3%">
                        <col style="width:6.3%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>신청월</th>
                            <th>채널</th>
                            <th>제휴카드</th>
                            <th>6개월고객수</th>
                            <th>6개월금액</th>
                            <th>5개월고객수</th>
                            <th>5개월금액</th>
                            <th>4개월고객수</th>
                            <th>4개월금액</th>
                            <th>3개월고객수</th>
                            <th>3개월금액</th>
                            <th>2개월고객수</th>
                            <th>2개월금액</th>
                            <th>1개월고객수</th>
                            <th>1개월금액</th>
                            <th>합계고객수</th>
                            <th>합계금액</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(table,i) in zbil_card_ap_escape_prst" :key="i">
                            <template v-if="checkReqYmRowspan(table.reqYm, i) == true">
                                <td class="t-bold t-ct" :rowspan="getReqYmRowspan(table.reqYm)">{{table.reqYm}}</td>
                            </template>
                            <template v-if="checkChnlGbRowspan(table.reqYm, table.chnlGb, i)">
                                <td class="t-bold t-ct" :rowspan="getChnlGbRowspan(table.reqYm, table.chnlGb)">{{table.chnlGb}}</td>
                            </template>
                            <td class="t-ct">{{table.joinCardGb}}</td>
                            <td class="t-rt">{{table.m6Cnt}}</td>
                            <td class="t-rt">{{table.m6Amt}}</td>
                            <td class="t-rt">{{table.m5Cnt}}</td>
                            <td class="t-rt">{{table.m5Amt}}</td>
                            <td class="t-rt">{{table.m4Cnt}}</td>
                            <td class="t-rt">{{table.m4Amt}}</td>
                            <td class="t-rt">{{table.m3Cnt}}</td>
                            <td class="t-rt">{{table.m3Amt}}</td>
                            <td class="t-rt">{{table.m2Cnt}}</td>
                            <td class="t-rt">{{table.m2Amt}}</td>
                            <td class="t-rt">{{table.m1Cnt}}</td>
                            <td class="t-rt">{{table.m1Amt}}</td>
                            <td class="t-rt">{{table.totalCnt}}</td>
                            <td class="t-rt">{{table.totalAmt}}</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="t-ct" colspan="3">합계</td>
							<td class="t-rt"><a v-on:click="showPopUp()" style="text-decoration: underline; color: #ea002c;">{{this.zbil_card_ap_escape_prst_subTotal[0]}}</a></td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[1]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[2]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[3]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[4]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[5]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[6]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[7]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[8]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[9]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[10]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[11]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[12]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[13]}}</td>
                        </tr>
                    </tfoot>
                    </template>
                    <template v-else>
                    <colgroup>
                        <col style="width:6.3%">
                        <col style="width:5.7%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                        <col style="width:6.2%">
                        <col style="width:5.4%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>채널</th>
                            <th>제휴카드</th>
                            <th>6개월고객수</th>
                            <th>6개월금액</th>
                            <th>5개월고객수</th>
                            <th>5개월금액</th>
                            <th>4개월고객수</th>
                            <th>4개월금액</th>
                            <th>3개월고객수</th>
                            <th>3개월금액</th>
                            <th>2개월고객수</th>
                            <th>2개월금액</th>
                            <th>1개월고객수</th>
                            <th>1개월금액</th>
                            <th>합계고객수</th>
                            <th>합계금액</th>
                            <th>신청월</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(table,i) in zbil_card_ap_escape_prst" :key="i">
                            <template v-if="checkChnlGbRowspan(table.reqYm, table.chnlGb, i)">
                                <td class="t-bold t-ct" :rowspan="getChnlGbRowspan(table.reqYm, table.chnlGb)">{{table.chnlGb}}</td>
                            </template>
                            <td class="t-ct">{{table.joinCardGb}}</td>
                            <td class="t-rt">{{table.m6Cnt}}</td>
                            <td class="t-rt">{{table.m6Amt}}</td>
                            <td class="t-rt">{{table.m5Cnt}}</td>
                            <td class="t-rt">{{table.m5Amt}}</td>
                            <td class="t-rt">{{table.m4Cnt}}</td>
                            <td class="t-rt">{{table.m4Amt}}</td>
                            <td class="t-rt">{{table.m3Cnt}}</td>
                            <td class="t-rt">{{table.m3Amt}}</td>
                            <td class="t-rt">{{table.m2Cnt}}</td>
                            <td class="t-rt">{{table.m2Amt}}</td>
                            <td class="t-rt">{{table.m1Cnt}}</td>
                            <td class="t-rt">{{table.m1Amt}}</td>
                            <td class="t-rt">{{table.totalCnt}}</td>
                            <td class="t-rt">{{table.totalAmt}}</td>
                            <template v-if="checkReqYmRowspan(table.reqYm, i) == true">
                                <td class="t-bold t-ct" :rowspan="getReqYmRowspan(table.reqYm)">{{table.reqYm}}</td>
                            </template>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="t-ct" colspan="2">합계</td>
							<td class="t-rt"><a href="da004pop" target="_blank" class="link" style="text-decoration: underline; color: #ea002c;">{{this.zbil_card_ap_escape_prst_subTotal[0]}}</a></td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[1]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[2]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[3]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[4]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[5]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[6]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[7]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[8]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[9]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[10]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[11]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[12]}}</td>
                            <td class="t-rt">{{this.zbil_card_ap_escape_prst_subTotal[13]}}</td>
                            <td class="t-rt"></td>
                        </tr>
                    </tfoot>
                    </template>                    
                </table>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA004",
    components: {
       appLnbMenu,
    },
    data() {
        return {
            strdYm: '202011',
            bfAfGb: 'AF',
            settlWayNm: '계좌이체',
            zbil_card_ap_escape_prst: {
                strdYm :[],    
                reqYm :[],     
                chnlGb :[],    
                settlWayNm :[],
                joinCardGb :[],
                bfAfGb :[],    
                auditNm :[],   
                auditDtm :[],  
                m6Cnt :[],     
                m6Amt :[],     
                m5Cnt :[],     
                m5Amt :[],     
                m4Cnt :[],     
                m4Amt :[],     
                m3Cnt :[],     
                m3Amt :[],     
                m2Cnt :[],     
                m2Amt :[],     
                m1Cnt :[],     
                m1Amt :[],     
                totalCnt :[],  
                totalAmt :[],  
            },
            zbil_card_ap_escape_prst_subTotal: [],
            bfChnlGb: '',
            bfReqYm: '',
            reqYmRowSpan: '',
            chnlGbRowSpan: '',
        };
    },

    methods: {

        Onclick_search: function () {
            console.log('in Onclick_search');

            this.bfAfGb = $('input[name="selectBfAfGb"]:checked').val();

            console.log("Search strdYm : " + this.strdYm);
            console.log("Search bfAfGb : " + this.bfAfGb);
            console.log("Search settlWayNm : " + this.settlWayNm);

            axios.post('http://13.124.162.248:5000/zbil_card_ap_escape_prst', {strdYm: this.strdYm, bfAfGb: this.bfAfGb, settlWayNm: this.settlWayNm }).then(res => {
                console.log(res);

                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.<퍼블리싱 필요>');
                    console.log('결과없음');
                    return;
                }
                
                // Grid Data Setting
                this.zbil_card_ap_escape_prst = res.data;

                // Calculate SubTotal
                this.calSubTotal();                

                $("#selectedStrdYm").html(this.strdYm.substr(0,4) + "년 " + this.strdYm.substr(4,2) + "월");
                $("#selectedStrdYmTotal").html( "total :<strong>"+this.zbil_card_ap_escape_prst_subTotal[13] + "</strong>");

            });
        },

        calSubTotal: function() {
            var tempSubTotalM6Cnt = 0;
            var tempSubTotalM6Amt = 0;
            var tempSubTotalM5Cnt = 0;
            var tempSubTotalM5Amt = 0;
            var tempSubTotalM4Cnt = 0;
            var tempSubTotalM4Amt = 0;
            var tempSubTotalM3Cnt = 0;
            var tempSubTotalM3Amt = 0;
            var tempSubTotalM2Cnt = 0;
            var tempSubTotalM2Amt = 0;
            var tempSubTotalM1Cnt = 0;
            var tempSubTotalM1Amt = 0;
            var tempSubTotalTotalCnt = 0;
            var tempSubTotalTotalAmt = 0;

            // reqYm 이 같으면 각 Column에 누적
            for(var i=0; i<this.zbil_card_ap_escape_prst.length; i++){
                tempSubTotalM6Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m6Cnt.replaceAll(',',''));   
                tempSubTotalM6Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m6Amt.replaceAll(',',''));   
                tempSubTotalM5Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m5Cnt.replaceAll(',',''));   
                tempSubTotalM5Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m5Amt.replaceAll(',',''));   
                tempSubTotalM4Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m4Cnt.replaceAll(',',''));   
                tempSubTotalM4Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m4Amt.replaceAll(',',''));   
                tempSubTotalM3Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m3Cnt.replaceAll(',',''));   
                tempSubTotalM3Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m3Amt.replaceAll(',',''));   
                tempSubTotalM2Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m2Cnt.replaceAll(',',''));   
                tempSubTotalM2Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m2Amt.replaceAll(',',''));   
                tempSubTotalM1Cnt     += parseInt(this.zbil_card_ap_escape_prst[i].m1Cnt.replaceAll(',',''));   
                tempSubTotalM1Amt     += parseInt(this.zbil_card_ap_escape_prst[i].m1Amt.replaceAll(',',''));   
                tempSubTotalTotalCnt  += parseInt(this.zbil_card_ap_escape_prst[i].totalCnt.replaceAll(',',''));
                tempSubTotalTotalAmt  += parseInt(this.zbil_card_ap_escape_prst[i].totalAmt.replaceAll(',',''));
            }

            console.log("tempSubTotalM6Cnt : "+tempSubTotalM6Cnt);

            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM6Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM6Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM5Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM5Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM4Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM4Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM3Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM3Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM2Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM2Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM1Cnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalM1Amt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalTotalCnt));
            this.zbil_card_ap_escape_prst_subTotal.push( this.CommaFormat(tempSubTotalTotalAmt));

        },

        CommaFormat : function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },


        //Changed StrdYm
        changeStrdYm(event){
            console.log("Before : " + this.strdYm);
            this.strdYm = event.target.value;
            console.log("After : " + this.strdYm);
        },

        //in V-if method
        checkReqYmRowspan(reqYm, index){
            var bfReqYm = 0;

            if(reqYm == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfReqYm = this.zbil_card_ap_escape_prst[index-1].reqYm;

            if(bfReqYm != reqYm){
                return true;
            }            
            return false;
        },
        getReqYmRowspan(reqYm){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_card_ap_escape_prst.length; i++){
                if(this.zbil_card_ap_escape_prst[i].reqYm == reqYm){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },
        
        //in V-if method
        checkChnlGbRowspan(reqYm, chnlGb, index){
            var bfChnlGb = 0;

            if(reqYm == null){
                return;
            }

            if(index == 0){
                return true;
            }
            
            bfChnlGb = this.zbil_card_ap_escape_prst[index-1].chnlGb;

            if(bfChnlGb != chnlGb){
                return true;
            }            
            return false;
        },

        getChnlGbRowspan(reqYm, chnlGb){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_card_ap_escape_prst.length; i++){
                if((this.zbil_card_ap_escape_prst[i].reqYm == reqYm) && (this.zbil_card_ap_escape_prst[i].chnlGb == chnlGb)){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },

        showPopUp: function(){
            console.log("strdYm : " + this.strdYm);
            console.log("bfAfGb : " + this.bfAfGb);
            window.open("/DA004POP?strdYm="+this.strdYm+"&bfAfGb="+this.bfAfGb);
        },
    },
    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search();
    },
};


</script>