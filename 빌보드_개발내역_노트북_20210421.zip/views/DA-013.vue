<template>
        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">카드사별 인출오류 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출오류 분석</li>
                    <li>카드사별 인출오류 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <!-- <label>인출월</label>
                            <span class="select-custom">
                                <select id='selectDrwYmFr' @change="changeDrwYmFr($event)">
                                    <option value='202007'>2020년 07월</option>
                                    <option value='202008'>2020년 08월</option>
                                    <option value='202009' selected>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011'>2020년 11월</option>
                                    <option value='202012'>2020년 12월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select id='selectDrwYmTo' @change="changeDrwYmTo($event)">
                                    <option value='202007'>2020년 07월</option>
                                    <option value='202008'>2020년 08월</option>
                                    <option value='202009'>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011' selected>2020년 11월</option>
                                    <option value='202012'>2020년 12월</option>
                                </select>
                            </span> -->
                            <label>인출월</label>
                            <span class="datepick-custom">
                                <date-picker v-model="dateDrwYmFr" type="month"></date-picker>
                                <i class="ri-calendar-line"></i>
                            </span>
                            <span class="datepick-custom">
                                <date-picker v-model="dateDrwYmTo" type="month"></date-picker>
                                <i class="ri-calendar-line"></i>
                            </span>
                        </li>
                        <li>
                            <label>카드사</label>
                            <span class="select-custom">
                                <select id='selectCardNm' @change="changeCardNm($event)">
                                    <option value='전체' selected>전체</option>
                                    <option value='삼성카드'>삼성카드</option>
                                    <option value='신한카드'>신한카드</option>
                                    <option value='롯데카드'>롯데카드</option>
                                    <option value='현대카드'>현대카드</option>
                                    <option value='BC카드'>BC카드</option>
                                    <option value='국민카드'>국민카드</option>
                                    <option value='하나카드(구외환)'>하나카드(구외환)</option>
                                    <option value='씨티카드'>씨티카드</option>
                                    <option value='NH카드'>NH카드</option>
                                    <option value='하나카드'>하나카드</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col>
                    <col style="width:14%;">
                    <col style="width:9%;">
                    <col style="width:9%;">
                    <col style="width:9%;">
                    <col style="width:13%;">
                    <col style="width:13%;">
                    <col style="width:13%;">
                    <col style="width:10%;">
                </colgroup>
                <thead>
                    <tr>
                        <th>인출월</th>
                        <th>카드사명</th>
                        <th>인출요청건수</th>
                        <th>인출건수</th>
                        <th>미인출건수</th>
                        <th>인출요청금액</th>
                        <th>인출금액</th>
                        <th>미인출금액</th>
                        <th>인출율(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(table,i) in zbil_card_co_drw_stc" :key="i">
                        <template v-if="checkDrwYmRowspan(table.drwYm, i) == true">
                            <td class="t-bold t-ct" :rowspan="getDrwYmRowspan(table.drwYm)">{{table.drwYm.substr(0,4) + "년 " + table.drwYm.substr(4,2) + "월"}}</td>
                        </template>
                        <template v-if="table.cardNm == '합계'">
                            <td class="t-ct totalTd">{{table.cardNm}}</td>
                            <td class="t-rt totalTd">{{table.drwReqCnt}}</td>
                            <td class="t-rt totalTd">{{table.norDrwCnt}}</td>
                            <td class="t-rt totalTd">{{table.errDrwCnt}}</td>
                            <td class="t-rt totalTd">{{table.drwReqAmt}}</td>
                            <td class="t-rt totalTd">{{table.norDrwAmt}}</td>
                            <td class="t-rt totalTd">{{table.errDrwAmt}}</td>
                            <td class="t-ct totalTd">{{table.amtDrwRt}}</td>
                        </template>
                        <template v-else>
                            <td class="t-ct">{{table.cardNm}}</td>
                            <td class="t-rt">{{table.drwReqCnt}}</td>
                            <td class="t-rt">{{table.norDrwCnt}}</td>
                            <td class="t-rt">{{table.errDrwCnt}}</td>
                            <td class="t-rt">{{table.drwReqAmt}}</td>
                            <td class="t-rt">{{table.norDrwAmt}}</td>
                            <td class="t-rt">{{table.errDrwAmt}}</td>
                            <td class="t-ct">{{table.amtDrwRt}}</td>
                        </template>
                    </tr>
                </tbody>
            </table>
        </div>
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import 'vue2-datepicker/locale/ko';

export default {
    name: "DA013",

    components: {
       DatePicker,
    },

    data() {
        return {
            dateDrwYmTo: new Date(),
            dateDrwYmFr: new Date(new Date().getFullYear(), new Date().getMonth()-2, new Date().getDate()),

            drwYmFr: '',
            drwYmTo: '',
            cardNm: '전체',
            zbil_card_co_drw_stc: {
                drwYm :[],
                cardCd :[],
                cardNm :[],
                drwReqCnt :[],
                norDrwCnt :[],
                errDrwCnt :[],
                drwReqAmt :[],
                norDrwAmt :[],
                errDrwAmt :[],
                amtDrwRt :[],
            },            
        };
    },

    methods: {
        Onclick_search: function () {
            console.log('in Onclick_search');

            if(this.dateDrwYmFr.getMonth()+1 < 10){
                this.drwYmFr = '' + this.dateDrwYmFr.getFullYear() + '0' + (this.dateDrwYmFr.getMonth()+1);
            }else{
                this.drwYmFr = '' + this.dateDrwYmFr.getFullYear() + (this.dateDrwYmFr.getMonth()+1);
            }

            if(this.dateDrwYmTo.getMonth()+1 < 10){
                this.drwYmTo = '' + this.dateDrwYmTo.getFullYear() + '0' + (this.dateDrwYmTo.getMonth()+1);
            }else{
                this.drwYmTo = '' + this.dateDrwYmTo.getFullYear() + (this.dateDrwYmTo.getMonth()+1);
            }

            console.log("Search drwYmFr : " + this.drwYmFr);
            console.log("Search drwYmTo : " + this.drwYmTo);
            console.log("Search cardNm : " + this.cardNm);
            
            axios.post('http://13.124.162.248:5000/zbil_card_co_drw_stc', {drwYmFr: this.drwYmFr, drwYmTo: this.drwYmTo, cardNm: this.cardNm }).then(res => {
                console.log(res);

                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.');
                    console.log('결과없음');
                    return;
                }
                
                // Grid Data Setting
                this.zbil_card_co_drw_stc = res.data;

                // 조회조건 Setting
                $("#selectCardNm").value = this.cardNm;
            
            });
        },

        //Changed cardNm
        changeCardNm(event){
            console.log("Before : " + this.cardNm);
            this.cardNm = event.target.value;
            console.log("After : " + this.cardNm);
        },   

        //in V-if method
        checkDrwYmRowspan(drwYm, index){
            var bfDrwYm = 0;

            if(drwYm == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfDrwYm = this.zbil_card_co_drw_stc[index-1].drwYm;

            if(bfDrwYm != drwYm){
                return true;
            }            
            return false;
        },
        getDrwYmRowspan(drwYm){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_card_co_drw_stc.length; i++){
                if(this.zbil_card_co_drw_stc[i].drwYm == drwYm){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },

    },     

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search(); 
    }
};


</script>