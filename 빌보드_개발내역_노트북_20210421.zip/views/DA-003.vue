<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content">
            <div class="cont-top">
                <h2 class="tit">채널별 계좌전환현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>채널별 계좌전환현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>전환월</label>
                            <span class="select-custom">
                                <select id='selectFromReqMth' @change="changeFromReqMth($event)">
                                    <option value='202009' selected>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011'>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select id='selectToReqMth' @change="changeToReqMth($event)">
                                    <option value='202009'>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011' selected>2020년 11월</option>
                                </select>
                            </span>
                        </li>                        
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->
            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->
            <div class="layout">
                <div class="lt" style="width:70%">
                    <table class="tbl">
                        <colgroup>                            
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                            <col style="width:14.2%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>월</th>
                                <th>구분</th>
                                <th>채널</th>
                                <th>전환모수</th>
                                <th>전환수</th>
                                <th>전환율</th>
                                <th>유지율</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(table,i) in zbil_chnl_bank_cvnt_prst" :key="i">
                                <template v-if="checkReqMthRowspan(table.reqMth, i) == true">
                                    <td class="t-bold t-ct" :rowspan="getReqMthRowspan(table.reqMth)">{{table.reqMth.substr(0,4)}}년 {{table.reqMth.substr(4,2)}}월</td>
                                </template>
                                <td class="t-ct">{{table.prmGb}}</td>
                                <td class="t-ct">{{table.reqChnl}}</td>
                                <td class="t-rt">{{table.totCvntCnt}}</td>
                                <td class="t-rt">{{table.cvntCnt}}</td>
                                <td class="t-rt">{{table.cvntRt}}</td>
                                <td class="t-rt">{{table.keepRt}}</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td class="t-ct" colspan="3">수납 합계</td>
                                <td class="t-rt">{{this.zbil_chnl_bank_cvnt_prst_subTotal[0]}}</td>
                                <td class="t-rt">{{this.zbil_chnl_bank_cvnt_prst_subTotal[1]}}</td>
                                <td class="t-rt">{{this.zbil_chnl_bank_cvnt_prst_subTotal[2]}}</td>
                                <td class="t-rt">{{this.zbil_chnl_bank_cvnt_prst_subTotal[3]}}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="rt" style="width:30%">
                    <div class="chart-area">
                        <h3>채널별/월별 전환 수</h3>
                        <div class="chart-cont">
                            <chart-bar :chart-data="this.chartData" :options="this.chartOptions"></chart-bar>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartBar from "./components/ChartBar.js";

export default {
    name: "DA003",
    components: {
       appLnbMenu,
       ChartBar,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                // //hoverBackgroundColor: "red",
                // //hoverBorderWidth: 10,
                // // labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                // labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                // datasets: [
                //     {
                //         label: "전환모수1",
                //         // backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                //         backgroundColor: "#5978f5",
                //         data: [10,9,8,7,6,5,4,3,2,1],
                //     },
                //     {
                //         label: "전환수1",
                //         // backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                //         backgroundColor: "#eb8439",
                //         data: [1,2,3,4,5,6,7,8,9,10],
                //     }
                // ]
            },
            fromReqMth:'202009',
            toReqMth  :'202011',
            zbil_chnl_bank_cvnt_prst: {
                reqMth :[],    
                prmGb :[],    
                reqChnl :[],   
                totCvntCnt :[],
                cvntCnt :[],   
                cvntRt :[],    
                keepRt :[], 
            },
            zbil_chnl_bank_cvnt_prst_subTotal: [],
            ArrChartLabel: [],
            ArrChartDataTotCvntCnt: [],
            ArrChartDataCvntCnt: [],
        };
    },
    methods: {
        Onclick_search: function () {
            console.log('in Onclick_search');

            console.log("Search fromReqMth : " + this.fromReqMth);
            console.log("Search toReqMth : " + this.toReqMth);      

            axios.post('http://13.124.162.248:5000/zbil_chnl_bank_cvnt_prst', {fromReqMth: this.fromReqMth, toReqMth: this.toReqMth }).then(res => {
                console.log(res);
                
                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.<퍼블리싱 필요>');
                    console.log('결과없음');
                    return;
                }

                this.zbil_chnl_bank_cvnt_prst = res.data;

                // Caluate SubTotal
                this.calSubTotal();

                // Make Chart Label and Data
                this.makeChartData();

                // Rendering Chart
                this.renderChart();

            });
        },

        calSubTotal: function() {
            var tempSubTotaltotCvntCnt = 0;
            var tempSubTotalcvntCnt = 0;

            this.zbil_chnl_bank_cvnt_prst_subTotal = [];

            // reqYm 이 같으면 각 Column에 누적
            for(var i=0; i<this.zbil_chnl_bank_cvnt_prst.length; i++){
                tempSubTotaltotCvntCnt += parseInt(this.zbil_chnl_bank_cvnt_prst[i].totCvntCnt.replaceAll(',',''));   
                tempSubTotalcvntCnt    += parseInt(this.zbil_chnl_bank_cvnt_prst[i].cvntCnt.replaceAll(',',''));   
            }

            this.zbil_chnl_bank_cvnt_prst_subTotal.push( this.CommaFormat(tempSubTotaltotCvntCnt));
            this.zbil_chnl_bank_cvnt_prst_subTotal.push( this.CommaFormat(tempSubTotalcvntCnt));
            this.zbil_chnl_bank_cvnt_prst_subTotal.push( (tempSubTotalcvntCnt/tempSubTotaltotCvntCnt*100).toFixed(2) );
            this.zbil_chnl_bank_cvnt_prst_subTotal.push( ((tempSubTotaltotCvntCnt-tempSubTotalcvntCnt)/tempSubTotaltotCvntCnt*100).toFixed(2) );
        },

        CommaFormat : function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        makeChartData: function() {
            this.ArrChartLabel = [];
            this.ArrChartDataTotCvntCnt = [];
            this.ArrChartDataCvntCnt = [];

            // reqYm 이 같으면 각 Column에 누적
            for(var i=0; i<this.zbil_chnl_bank_cvnt_prst.length; i++){
                this.ArrChartLabel.push( this.zbil_chnl_bank_cvnt_prst[i].reqMth + this.zbil_chnl_bank_cvnt_prst[i].reqChnl );
                this.ArrChartDataTotCvntCnt.push( this.zbil_chnl_bank_cvnt_prst[i].totCvntCnt.replaceAll(',','') );
                this.ArrChartDataCvntCnt.push( this.zbil_chnl_bank_cvnt_prst[i].cvntCnt.replaceAll(',','') );                
            }
        },

        renderChart: function() {
            console.log("in renderChart");

            let chartData3 = {
                labels: this.ArrChartLabel,
                datasets: [
                    {
                        label: "전환모수",
                        // backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        backgroundColor: "#5978f5",
                        data: this.ArrChartDataTotCvntCnt,
                    },
                    {
                        label: "전환수",
                        // backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        backgroundColor: "#eb8439",
                        data: this.ArrChartDataCvntCnt,
                    }
                ]
            };
            this.chartData = chartData3;
        },

        //Changed fromReqMth
        changeFromReqMth(event){
            console.log("Before : " + this.fromReqMth);
            this.fromReqMth = event.target.value;
            console.log("After : " + this.fromReqMth);
        },
        
        //Changed toReqMth
        changeToReqMth(event){
            console.log("Before : " + this.toReqMth);
            this.toReqMth = event.target.value;
            console.log("After : " + this.toReqMth);
        },

        //in V-if method
        checkReqMthRowspan(reqMth, index){
            var bfReqMth = 0;

            if(reqMth == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfReqMth = this.zbil_chnl_bank_cvnt_prst[index-1].reqMth;

            if(bfReqMth != reqMth){
                return true;
            }            
            return false;
        },

        getReqMthRowspan(reqMth){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_chnl_bank_cvnt_prst.length; i++){
                if(this.zbil_chnl_bank_cvnt_prst[i].reqMth == reqMth){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },
    },
    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search();
    }
};





</script>