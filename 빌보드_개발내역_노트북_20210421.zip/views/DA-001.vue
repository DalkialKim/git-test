<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content">
            <div class="cont-top">
                <h2 class="tit">월별납부현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납 고객 분석</li>
                    <li>월별납부현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>수납월</label>
                            <span class="select-custom">
                                <select>
                                    <option>2020년 09월</option>
                                    <option>2020년 10월</option>
                                    <option>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->
            <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div>
            <!-- //tbl-top -->
            <div class="layout">
                <div class="lt" style="width:70%">
                    <table class="tbl">
                        <colgroup>
                            <col>
                            <col style="width:16%">
                            <col style="width:16%">
                            <col style="width:16%">
                            <col style="width:16%">
                            <col style="width:16%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>구분</th>
                                <th>납부방법</th>
                                <th>수납건수(납부)</th>
                                <th>비율(건수)</th>
                                <th>수납금액</th>
                                <th>비율(금액)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="t-bold b-bm t-ct">카드자동납부 청구</td>
                                <td class="t-rt b-bm"></td>
                                <td class="t-rt b-bm">9,999,999</td>
                                <td class="t-rt b-bm"></td>
                                <td class="t-rt b-bm">9,999,999</td>
                                <td class="t-rt b-bm"></td>
                            </tr>
                            <tr>
                                <td class="t-bold b-bm t-ct" rowspan="2">카드자동납부 수납</td>
                                <td>카드 자동 납부</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt">83.97%</td>
                            </tr>
                            <tr>
                                <td class="b-lt b-bm">소계</td>
                                <td class="t-rt b-bm">9,999,999</td>
                                <td class="t-rt b-bm"></td>
                                <td class="t-rt b-bm">9,999,999</td>
                                <td class="t-rt b-bm"></td>
                            </tr>
                            <tr>
                                <td class="t-bold t-ct" rowspan="11">타납부방법 수납</td>
                                <td>카드</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="cr-r b-lt">입금전용 계좌</td>
                                <td class="t-rt cr-r">9,999,999</td>
                                <td class="t-rt cr-r" rowspan="3">0.98</td>
                                <td class="t-rt cr-r">9,999,999</td>
                                <td class="t-rt cr-r" rowspan="3">0.98</td>
                            </tr>
                            <tr>
                                <td class="cr-r b-lt">현금</td>
                                <td class="t-rt cr-r">9,999,999</td>
                                <td class="t-rt cr-r">9,999,999</td>
                            </tr>
                            <tr>
                                <td class="cr-r b-lt">계좌이체</td>
                                <td class="t-rt cr-r">9,999,999</td>
                                <td class="t-rt cr-r">9,999,999</td>
                            </tr>
                            <tr>
                                <td class="b-lt">대체</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">SKpay카드</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">SKpay계좌이체</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">OK캐쉬백</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">SK상품권</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">지로</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>
                            <tr>
                                <td class="b-lt">소계</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt"></td>
                            </tr>                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td class="t-ct" colspan="2">수납 합계</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt">100%</td>
                                <td class="t-rt">9,999,999</td>
                                <td class="t-rt">100%</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="rt" style="width:30%">
                    <div class="chart-area">
                        <h3>카드자동납부 외 수납 비중</h3>
                        <div class="chart-cont">
                            <chart-pie :data="chartData" :options="chartOptions"></chart-pie>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";
import ChartPie from "./components/ChartPie.js";

export default {
    name: "DA001",
    components: {
       appLnbMenu,
       ChartPie,
    },

    data() {
        return {
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                datasets: [
                    {
                        label: "Data One",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                    }
                ]
            }
        };
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });
    }
};





</script>