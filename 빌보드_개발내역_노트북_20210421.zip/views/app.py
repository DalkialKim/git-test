from flask import Flask, jsonify, request,session, json, Response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

import pymysql

from my_util.my_logger import my_logger
from my_provider.baseball_scrapper import get_baseball_rank
from my_model import user_model

import os, traceback, logging

# instantiate the app
app = Flask(__name__)

# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}}, supports_credentials=True)

#db connect info
rds_endpoint = "billboard-data-test.cwweyzvcsqwn.ap-northeast-2.rds.amazonaws.com"
username = "admin"
password = "adminadmin" # RDS Mysql password
db_name = "BDS" # RDS MySQL DB name
conn = None

db = pymysql.connect(rds_endpoint, user=username, passwd=password, db=db_name, connect_timeout=5, charset='utf8')
cursor = db.cursor(pymysql.cursors.DictCursor)

# sanity check route
@app.route('/zbil_card_ap_escape_prst', methods=['POST'])
def zbil_card_ap_escape_prst_post():
    return_data = []
    
    input_strdYm = request.json['strdYm']
    input_bfAfGb = request.json['bfAfGb']
    input_settlWayNm = request.json['settlWayNm']

    input_data = (input_strdYm, input_settlWayNm, input_bfAfGb, input_strdYm, input_strdYm)

    sql = """SELECT STRD_YM, REQ_YM, CHNL_GB, SETTL_WAY_NM, JOIN_CARD_GB, BF_AF_GB,
                    FORMAT(M6_CNT, 0) AS M6_CNT, FORMAT(M6_AMT, 0) AS M6_AMT,
                    FORMAT(M5_CNT, 0) AS M5_CNT, FORMAT(M5_AMT, 0) AS M5_AMT,
                    FORMAT(M4_CNT, 0) AS M4_CNT, FORMAT(M4_AMT, 0) AS M4_AMT,
                    FORMAT(M3_CNT, 0) AS M3_CNT, FORMAT(M3_AMT, 0) AS M3_AMT,
                    FORMAT(M2_CNT, 0) AS M2_CNT, FORMAT(M2_AMT, 0) AS M2_AMT,
                    FORMAT(M1_CNT, 0) AS M1_CNT, FORMAT(M1_AMT, 0) AS M1_AMT,
                    FORMAT(TOTAL_CNT, 0) AS TOTAL_CNT, FORMAT(TOTAL_AMT, 0) AS TOTAL_AMT
            FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST
            WHERE STRD_YM = %s AND SETTL_WAY_NM = %s AND BF_AF_GB = %s 
              AND REQ_YM = CASE WHEN BF_AF_GB = 'AF'
                                THEN ( SELECT MIN(REQ_YM) FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST WHERE STRD_YM = %s )
                                ELSE ( SELECT MAX(REQ_YM) FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST WHERE STRD_YM = %s )
                            END
            ORDER BY REQ_YM, CHNL_GB, JOIN_CARD_GB;"""

    cursor.execute(sql,input_data )
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['strdYm']     = data['STRD_YM']
        obj['reqYm']      = data['REQ_YM']
        obj['chnlGb']     = data['CHNL_GB']
        obj['settlWayNm'] = data['SETTL_WAY_NM']
        obj['joinCardGb'] = data['JOIN_CARD_GB']
        obj['bfAfGb']     = data['BF_AF_GB']
        # obj['auditNm']    = data['AUDIT_NM']
        # obj['auditDtm']   = data['AUDIT_DTM']
        obj['m6Cnt']      = data['M6_CNT']
        obj['m6Amt']      = data['M6_AMT']
        obj['m5Cnt']      = data['M5_CNT']
        obj['m5Amt']      = data['M5_AMT']
        obj['m4Cnt']      = data['M4_CNT']
        obj['m4Amt']      = data['M4_AMT']
        obj['m3Cnt']      = data['M3_CNT']
        obj['m3Amt']      = data['M3_AMT']
        obj['m2Cnt']      = data['M2_CNT']
        obj['m2Amt']      = data['M2_AMT']
        obj['m1Cnt']      = data['M1_CNT']
        obj['m1Amt']      = data['M1_AMT']
        obj['totalCnt']   = data['TOTAL_CNT']
        obj['totalAmt']   = data['TOTAL_AMT']

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response

# sanity check route
@app.route('/zbil_chnl_bank_cvnt_prst', methods=['POST'])
def zbil_chnl_bank_cvnt_prst_post():
    return_data = []
    
    input_fromReqMth = request.json['fromReqMth']
    input_toReqMth = request.json['toReqMth']

    input_data = (input_fromReqMth, input_toReqMth)

    sql = """SELECT REQ_MTH, REQ_CHNL, FORMAT(TOT_CVNT_CNT,0) AS TOT_CVNT_CNT, FORMAT(CVNT_CNT,0) AS CVNT_CNT, CVNT_RT, KEEP_RT
               FROM BDS.ZBIL_CHNL_BANK_CVNT_PRST
              WHERE REQ_MTH BETWEEN %s AND %s
             ORDER BY REQ_MTH, TOT_CVNT_CNT;"""

    cursor.execute(sql,input_data )
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['reqMth']     = data['REQ_MTH']
        obj['reqChnl']    = data['REQ_CHNL']
        obj['totCvntCnt'] = data['TOT_CVNT_CNT']
        obj['cvntCnt']    = data['CVNT_CNT']
        obj['cvntRt']     = data['CVNT_RT']
        obj['keepRt']     = data['KEEP_RT']

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response

@app.route('/zbil_card_ap_escape_prst_dtl', methods=['POST'])
def zbil_card_ap_escape_prst_dtl_post():
    return_data = []
    
    input_strdYm = request.json['strdYm']
    input_bfAfGb = request.json['bfAfGb']

    input_data = (input_strdYm, input_bfAfGb, input_strdYm, input_strdYm)

    sql = """SELECT STRD_YM, REQ_YM, CONVERT(ACNT_NUM,CHAR) AS ACNT_NUM, BF_AF_GB, CARD_NUM, AGE_GB, REQ_CHNL, BF_PAY_MTHD_NM, BANK_AP_YN, KEEP_PRD,
                    FORMAT(TOTAL_AMT,0) AS TOTAL_AMT,FORMAT(M6_AMT,0) AS M6_AMT,FORMAT(M5_AMT,0) AS M5_AMT,
                    FORMAT(M4_AMT,0) AS M4_AMT,FORMAT(M3_AMT,0) AS M3_AMT,FORMAT(M2_AMT,0) AS M2_AMT,FORMAT(M1_AMT,0) AS M1_AMT
               FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST_DTL
              WHERE STRD_YM = %s AND BF_AF_GB = %s
                AND REQ_YM = CASE WHEN BF_AF_GB = 'AF'
                                    THEN ( SELECT MIN(REQ_YM) FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST_DTL WHERE STRD_YM = %s )
                                    ELSE ( SELECT MAX(REQ_YM) FROM BDS.ZBIL_CARD_AP_ESCAPE_PRST_DTL WHERE STRD_YM = %s )
                                END
             ORDER BY REQ_YM, REQ_CHNL, BF_AF_GB;"""

    cursor.execute(sql,input_data )
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['strdYm']       = data['STRD_YM']
        obj['reqYm']        = data['REQ_YM']
        obj['acntNum']      = data['ACNT_NUM']
        obj['bfAfGb']       = data['BF_AF_GB']
        obj['cardNum']      = data['CARD_NUM']
        obj['ageGb']        = data['AGE_GB']
        obj['reqChnl']      = data['REQ_CHNL']
        obj['bfPayMthdNm']  = data['BF_PAY_MTHD_NM']
        obj['bankApYn']     = data['BANK_AP_YN']
        obj['keepPrd']      = data['KEEP_PRD']
        # obj['auditNm']    = data['AUDIT_NM']
        # obj['auditDtm']   = data['AUDIT_DTM']
        obj['totalAmt']     = data['TOTAL_AMT']
        obj['m6Amt']        = data['M6_AMT']
        obj['m5Amt']        = data['M5_AMT']
        obj['m4Amt']        = data['M4_AMT']
        obj['m3Amt']        = data['M3_AMT']
        obj['m2Amt']        = data['M2_AMT']
        obj['m1Amt']        = data['M1_AMT']        

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response

## 김화진 2020.12.16 >>>>> START
## 채널별 회차 신청/변경 현황 DA-012​
@app.route('/zbil_chnl_ts_req_stc', methods=['POST'])
def zbil_chnl_ts_req_stc_post():
    return_data = []

    input_reqYm = request.json['reqYm']
    input_reqTs = request.json['reqTs']

    input_data = (input_reqYm, input_reqTs, input_reqTs)

    sql = """SELECT REQ_CHNL
                  , NEW_CHG_CL
                  , FORMAT(REQ_TS,0)  AS REQ_TS
                  , FORMAT(REQ_CNT,0) AS REQ_CNT
               FROM BDS.ZBIL_CHNL_TS_REQ_STC
              WHERE REQ_YM = %s
                AND REQ_TS = if(%s = '9', REQ_TS, %s)
              ORDER BY REQ_CHNL, NEW_CHG_CL, REQ_TS;"""

    cursor.execute(sql,input_data )
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['reqChnl']  = data['REQ_CHNL']
        obj['newChgCl'] = data['NEW_CHG_CL']
        obj['reqTs']    = data['REQ_TS']
        obj['reqCnt']   = data['REQ_CNT']

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response

## 카드사별 인출오류 현황 DA-013
@app.route('/zbil_card_co_drw_stc', methods=['POST'])
def zbil_card_co_drw_stc_post():
    return_data = []

    input_drwYmFr = request.json['drwYmFr']
    input_drwYmTo = request.json['drwYmTo']
    input_cardNm = request.json['cardNm']

    input_data = (input_drwYmFr, input_drwYmTo, input_cardNm, input_cardNm)

    sql = """SELECT DRW_YM
                , CARD_NM
                , FORMAT(DRW_REQ_CNT,0) AS DRW_REQ_CNT
                , FORMAT(NOR_DRW_CNT,0) AS NOR_DRW_CNT
                , FORMAT(ERR_DRW_CNT,0) AS ERR_DRW_CNT
                , FORMAT(DRW_REQ_AMT,0) AS DRW_REQ_AMT
                , FORMAT(NOR_DRW_AMT,0) AS NOR_DRW_AMT
                , FORMAT(ERR_DRW_AMT,0) AS ERR_DRW_AMT
                , AMT_DRW_RT
             FROM BDS.ZBIL_CARD_CO_DRW_STC
            WHERE DRW_YM BETWEEN %s AND %s
              AND CARD_NM = IF(%s = '전체', CARD_NM, %s)
            ORDER BY DRW_YM, CARD_CD;"""

    cursor.execute(sql,input_data )
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['drwYm']     = data['DRW_YM']
        obj['cardNm']    = data['CARD_NM']
        obj['drwReqCnt'] = data['DRW_REQ_CNT']
        obj['norDrwCnt'] = data['NOR_DRW_CNT']
        obj['errDrwCnt'] = data['ERR_DRW_CNT']
        obj['drwReqAmt'] = data['DRW_REQ_AMT']
        obj['norDrwAmt'] = data['NOR_DRW_AMT']
        obj['errDrwAmt'] = data['ERR_DRW_AMT']
        obj['amtDrwRt']  = data['AMT_DRW_RT']

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response
## 김화진 2020.12.16 <<<<< END

## DA-015 회차별 인출오류 지속여부 현황
@app.route('/zbil_ts_drw_err_cont_stc', methods=['POST'])
def zbil_ts_drw_err_cont_stc_post():
    return_data = []
    
    input_drwYm = request.json['drwYm']
    input_cardNm = request.json['cardNm']
    input_cardErrTypNm = request.json['cardErrTypNm']

    input_data = (input_drwYm, input_cardNm, input_cardNm, input_cardErrTypNm, input_cardErrTypNm)

    sql = """SELECT CARD_NM,  CARD_ERR_TYP_NM, FORMAT(TS1_TOT_ERR_CNT, 0) AS TS1_TOT_ERR_CNT,
                    FORMAT(TS1_TOT_ERR_AMT,   0) AS TS1_TOT_ERR_AMT,
                    FORMAT(TS12_NOR_DRW_CNT,  0) AS TS12_NOR_DRW_CNT,
                    FORMAT(TS12_ERR_CONT_CNT, 0) AS TS12_ERR_CONT_CNT, TS12_ERR_CONT_RT,
                    FORMAT(TS12_ERR_CONT_AMT, 0) AS	TS12_ERR_CONT_AMT,
                    FORMAT(TS13_NOR_DRW_CNT,  0) AS	TS13_NOR_DRW_CNT ,
                    FORMAT(TS13_ERR_CONT_CNT, 0) AS	TS13_ERR_CONT_CNT, TS13_ERR_CONT_RT,
                    FORMAT(TS13_ERR_CONT_AMT, 0) AS	TS13_ERR_CONT_AMT
               FROM BDS.ZBIL_TS_DRW_ERR_CONT_STC
              WHERE DRW_YM = %s
                AND CASE WHEN %s = '전체' THEN CARD_NM = CARD_NM ELSE CARD_NM = %s END
                AND CASE WHEN %s = '전체' THEN CARD_ERR_TYP_NM = CARD_ERR_TYP_NM ELSE CARD_ERR_TYP_NM = %s END
                ;"""

    cursor.execute(sql,input_data)
    sqlresult = cursor.fetchall()

    for data in sqlresult:
        obj = {}
        obj['cardNm']         = data['CARD_NM']
        obj['cardErrTypNm']   = data['CARD_ERR_TYP_NM']
        obj['ts1TotErrCnt']   = data['TS1_TOT_ERR_CNT']
        obj['ts1TotErrAmt']   = data['TS1_TOT_ERR_AMT']
        obj['ts12NorDrwCnt']  = data['TS12_NOR_DRW_CNT']
        obj['ts12ErrContCnt'] = data['TS12_ERR_CONT_CNT']
        obj['ts12ErrContRt']  = data['TS12_ERR_CONT_RT']
        obj['ts12ErrContAmt'] = data['TS12_ERR_CONT_AMT']
        obj['ts13NorDrwCnt']  = data['TS13_NOR_DRW_CNT']
        obj['ts13ErrContCnt'] = data['TS13_ERR_CONT_CNT']
        obj['ts13ErrContRt']  = data['TS13_ERR_CONT_RT']
        obj['ts13ErrContAmt'] = data['TS13_ERR_CONT_AMT']

        return_data.append(obj)

    response = app.response_class(response=json.dumps(return_data, ensure_ascii=False).encode('utf8'),
    status=200,
    content_type='application/json; charset=utf-8')

    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=os.getenv('FLASK_RUN_PORT'),debug=os.getenv('FLASK_DEBUG'))
