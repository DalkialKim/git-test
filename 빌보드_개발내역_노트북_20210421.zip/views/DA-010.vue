<template>
    <div class="container">

        <app-lnb-menu></app-lnb-menu>

        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">카드사별 신청오류 유형별 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 신청오류 분석</li>
                    <li>카드사별 신청오류 유형별 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>신청월</label>
                            <span class="select-custom">
                                <select id='selectFromReqMth' @change="changeFromReqMth($event)">
                                    <option value='202009' selected>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011'>2020년 11월</option>
                                </select>
                            </span>
                            <span class="select-custom">
                                <select id='selectToReqMth' @change="changeToReqMth($event)">
                                    <option value='202009'>2020년 09월</option>
                                    <option value='202010'>2020년 10월</option>
                                    <option value='202011' selected>2020년 11월</option>
                                </select>
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->
            <!-- //tbl-top -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:10%">
                    <col style="width:16%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                    <col style="width:6.1%">
                </colgroup>
                <thead>
                    <tr>
                        <th>카드사</th>
                        <th>오류유형</th>
                        <th id='m1'>1월</th>
                        <th id='m2'>2월</th>
                        <th id='m3'>3월</th>
                        <th id='m4'>4월</th>
                        <th id='m5'>5월</th>
                        <th id='m6'>6월</th>
                        <th id='m7'>7월</th>
                        <th id='m8'>8월</th>
                        <th id='m9'>9월</th>
                        <th id='m10'>10월</th>
                        <th id='m11'>11월</th>
                        <th id='m12'>12월</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(table,i) in zbil_card_req_fail_prst" :key="i">
                        <template v-if="checkReqInstRowspan(table.reqInst, i) == true">
                            <td class="t-bold t-ct" :rowspan="getReqInstRowspan(table.reqInst)">{{table.reqInst}}</td>
                        </template>
                        <template v-if="table.failTyp == '합계'">
                            <td class="t-ct subTotal">{{table.failTyp}}</td>
                            <td class="t-rt subTotal">{{table.m1Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m2Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m3Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m4Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m5Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m6Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m7Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m8Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m9Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m10Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m11Cnt}}</td>
                            <td class="t-rt subTotal">{{table.m12Cnt}}</td>
                        </template>
                        <template v-else>
                            <td class="t-ct">{{table.failTyp}}</td>
                            <td class="t-rt">{{table.m1Cnt}}</td>
                            <td class="t-rt">{{table.m2Cnt}}</td>
                            <td class="t-rt">{{table.m3Cnt}}</td>
                            <td class="t-rt">{{table.m4Cnt}}</td>
                            <td class="t-rt">{{table.m5Cnt}}</td>
                            <td class="t-rt">{{table.m6Cnt}}</td>
                            <td class="t-rt">{{table.m7Cnt}}</td>
                            <td class="t-rt">{{table.m8Cnt}}</td>
                            <td class="t-rt">{{table.m9Cnt}}</td>
                            <td class="t-rt">{{table.m10Cnt}}</td>
                            <td class="t-rt">{{table.m11Cnt}}</td>
                            <td class="t-rt">{{table.m12Cnt}}</td>
                        </template>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2">합계</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[0]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[1]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[2]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[3]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[4]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[5]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[6]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[7]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[8]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[9]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[10]}}</td>
                        <td class="t-rt">{{this.zbil_card_req_fail_prst_toTal[11]}}</td>
                    </tr>
                </tfoot>
            </table>

        </div>
        <!-- //content -->
    </div>
    <!-- //container -->
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import appLnbMenu from "../layout/appLnbMenu";

export default {
    name: "DA010",
    components: {
       appLnbMenu,
    },

    data() {
        return {
            fromReqMth: '202009',
            toReqMth: '202011',
            zbil_card_req_fail_prst: {
                reqInst :[],
                failTyp :[],
                m1Cnt   :[],  
                m2Cnt   :[],  
                m3Cnt   :[],  
                m4Cnt   :[],  
                m5Cnt   :[],  
                m6Cnt   :[],  
                m7Cnt   :[],  
                m8Cnt   :[],  
                m9Cnt   :[],  
                m10Cnt  :[], 
                m11Cnt  :[], 
                m12Cnt  :[], 
            },
            zbil_card_req_fail_prst_toTal: [],
        };
    },

    methods: {
        
        Onclick_search: function () {
            console.log('in Onclick_search');

            console.log("Search fromReqMth : " + this.fromReqMth);
            console.log("Search toReqMth : " + this.toReqMth);      

            axios.post('http://13.124.162.248:5000/zbil_card_req_fail_prst', {fromReqMth: this.fromReqMth, toReqMth: this.toReqMth }).then(res => {
                console.log(res);
                
                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.<퍼블리싱 필요>');
                    console.log('결과없음');
                    return;
                }

                this.zbil_card_req_fail_prst = res.data;

                // Caluate SubTotal
                this.calSubTotal();

                // TH Hidden
                this.hideTHs();
            });
        },

        // Caluate SubTotal
        calSubTotal: function() {
            var tempSubTotalm1  = 0;
            var tempSubTotalm2  = 0;
            var tempSubTotalm3  = 0;
            var tempSubTotalm4  = 0;
            var tempSubTotalm5  = 0;
            var tempSubTotalm6  = 0;
            var tempSubTotalm7  = 0;
            var tempSubTotalm8  = 0;
            var tempSubTotalm9  = 0;
            var tempSubTotalm10 = 0;
            var tempSubTotalm11 = 0;
            var tempSubTotalm12 = 0;

            this.zbil_card_req_fail_prst_toTal = [];

            // failTyp 이 같으면 각 Column에 누적
            for(var i=0; i<this.zbil_card_req_fail_prst.length; i++){
                if(this.zbil_card_req_fail_prst[i].failTyp == '합계'){
                    tempSubTotalm1  += parseInt(this.zbil_card_req_fail_prst[i].m1Cnt.replaceAll(',',''));   
                    tempSubTotalm2  += parseInt(this.zbil_card_req_fail_prst[i].m2Cnt.replaceAll(',',''));
                    tempSubTotalm3  += parseInt(this.zbil_card_req_fail_prst[i].m3Cnt.replaceAll(',',''));
                    tempSubTotalm4  += parseInt(this.zbil_card_req_fail_prst[i].m4Cnt.replaceAll(',',''));
                    tempSubTotalm5  += parseInt(this.zbil_card_req_fail_prst[i].m5Cnt.replaceAll(',',''));
                    tempSubTotalm6  += parseInt(this.zbil_card_req_fail_prst[i].m6Cnt.replaceAll(',',''));
                    tempSubTotalm7  += parseInt(this.zbil_card_req_fail_prst[i].m7Cnt.replaceAll(',',''));
                    tempSubTotalm8  += parseInt(this.zbil_card_req_fail_prst[i].m8Cnt.replaceAll(',',''));
                    tempSubTotalm9  += parseInt(this.zbil_card_req_fail_prst[i].m9Cnt.replaceAll(',',''));
                    tempSubTotalm10 += parseInt(this.zbil_card_req_fail_prst[i].m10Cnt.replaceAll(',',''));
                    tempSubTotalm11 += parseInt(this.zbil_card_req_fail_prst[i].m11Cnt.replaceAll(',',''));
                    tempSubTotalm12 += parseInt(this.zbil_card_req_fail_prst[i].m12Cnt.replaceAll(',',''));   
                }
            }

            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm1) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm2) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm3) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm4) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm5) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm6) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm7) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm8) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm9) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm10) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm11) );
            this.zbil_card_req_fail_prst_toTal.push( this.CommaFormat(tempSubTotalm12) );
        },

        // 숫자에 콤마 추가
        CommaFormat : function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        //Changed fromReqMth
        changeFromReqMth: function(event){
            console.log("Before : " + this.fromReqMth);
            this.fromReqMth = event.target.value;
            console.log("After : " + this.fromReqMth);
        },
        
        //Changed toReqMth
        changeToReqMth: function(event){
            console.log("Before : " + this.toReqMth);
            this.toReqMth = event.target.value;
            console.log("After : " + this.toReqMth);
        },

        //in V-if method RowSpan 여부 확인
        checkReqInstRowspan: function(reqInst, index){
            var bfreqInst = 0;

            if(reqInst == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfreqInst = this.zbil_card_req_fail_prst[index-1].reqInst;

            if(bfreqInst != reqInst){
                return true;
            }            
            return false;
        },

        //in V-if method RowSpan 값 확인
        getReqInstRowspan: function(reqInst){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_card_req_fail_prst.length; i++){
                if(this.zbil_card_req_fail_prst[i].reqInst == reqInst){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },

        // hideTHs
        hideTHs: function(){
            // var fromMth = 0;
            // var toMth = 0;

        },
    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search();
    }
};





</script>