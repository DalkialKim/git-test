<template>
        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">채널별 회차 신청/변경 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출 분석</li>
                    <li>채널별 회차 신청/변경 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>신청월</label>
                            <span class="datepick-custom">
                                <date-picker v-model="dateReqYm" type="month"></date-picker>
                                <i class="ri-calendar-line"></i>
                            </span>
                        </li>
                        <li>
                            <label>회차</label>
                            <span class="select-custom">
                                <select id='selectReqTs' @change="changeReqTs($event)">
                                    <option value='9' selected>전체</option>
                                    <option value='1'>1회차</option>
                                    <option value='2'>2회차</option>
                                    <option value='3'>3회차</option>
                                </select>
                            </span>
                        </li>                        
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->

            <!-- <div class="tbl-top">
                <h3 class="tbl-tit">2020년 09월</h3>
                <span class="tbl-total">total :<strong>999</strong></span>
            </div> -->

            <!-- //tbl-top -->

            <div class="layout">
                <div class="lt" style="width:65%">
                    <table class="tbl t-ct">
                        <colgroup>
                            <col>
                            <col style="width:25%">
                            <col style="width:25%">
                            <col style="width:20%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>신청채널</th>
                                <th>신규/변경</th>
                                <th>회차</th>
                                <th>신청건수</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(table,i) in zbil_chnl_ts_req_stc" :key="i">

                                <template v-if="checkReqChnlRowspan(table.reqChnl, i) == true">
                                    <td class="t-bold b-bm" :rowspan="getReqChnlRowspan(table.reqChnl)">{{table.reqChnl}}</td>
                                </template>
                                <template v-if="checkNewChgClRowspan(table.reqChnl, table.newChgCl, i) == true">
                                    <td class="t-bold b-bm b-lt-s" :rowspan="getNewChgClRowspan(table.reqChnl, table.newChgCl)">{{table.newChgCl}}</td>
                                </template>
                                <template v-if="table.reqTs == 3">                                    
                                    <td class="b-bm b-lt-s hit">{{table.reqTs}}</td>
                                </template>
                                <template v-else>
                                    <td class="b-lt-s">{{table.reqTs}}</td>
                                </template>
                                <template v-if="table.reqTs == 3">                                    
                                    <td class="t-rt b-bm b-lt-s hit">{{table.reqCnt}}</td>
                                </template>
                                <template v-else>
                                    <td class="t-rt b-lt-s">{{table.reqCnt}}</td>
                                </template>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="rt" style="width:35%">
                    <div class="chart-area">
                        <h3>채널별 회차 신청/변경 현황</h3>
                        <div class="chart-cont">
                            <chart-bar :chartData="this.chartData" :options="this.chartOptions"></chart-bar>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import 'vue2-datepicker/locale/ko';
import ChartBar from "./components/ChartBar.js";

export default {
    name: "DA012",
    components: {
       DatePicker,
       ChartBar,
    },

    data() {
        return {
            dateReqYm: new Date(),
            reqYm: '',
            reqTs: '9',
            zbil_chnl_ts_req_stc: {
                reqChnl :[],    
                newChgCl :[],     
                reqTs :[],    
                reqCnt :[],
            },
            ArrChartLabel: [],
            ArrChartDataReqCnt: [],
 
            chartOptions: {
                //hoverBorderWidth: 20
            },        
            chartData: {
                //hoverBackgroundColor: "red",
                //hoverBorderWidth: 10,
                // labels: ["카드", "입금전용계좌", "현금","계좌이체", "대체", "SKpay카드", "SKpay계좌이체", "OK캐쉬백", "SK상품권", "지로"],
                // datasets: [
                //     {
                //         label: "Data One",
                //         backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                //         data: [200, 180, 160, 140, 120, 100, 80, 70, 60, 50],
                //     }
                // ]
            }
        };
    },

    methods: {
        Onclick_search: function () {
            console.log('in Onclick_search');

            if(this.dateReqYm.getMonth()+1 < 10){
                this.reqYm = '' + this.dateReqYm.getFullYear() + '0' + (this.dateReqYm.getMonth()+1);
            }else{
                this.reqYm = '' + this.dateReqYm.getFullYear() + (this.dateReqYm.getMonth()+1);
            }

            console.log("Search reqYm : " + this.reqYm);
            console.log("Search reqTs : " + this.reqTs);
            
            axios.post('http://13.124.162.248:5000/zbil_chnl_ts_req_stc', {reqYm: this.reqYm, reqTs: this.reqTs }).then(res => {
                console.log(res);

                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.');
                    console.log('결과없음');
                    return;
                }
                
                // Grid Data Setting
                this.zbil_chnl_ts_req_stc = res.data;

                // Cont Area Setting
                // $("#selectReqYm").value = this.reqYm;
                $("#selectReqTs").value = this.reqTs;                

                // Make Chart Label and Data
                this.makeChartData();

                // Rendering Chart
                this.renderChart();

            });

        },

        //Changed reqTs
        changeReqTs(event){
            console.log("Before : " + this.reqTs);
            this.reqTs = event.target.value;
            console.log("After : " + this.reqTs);
        },   

        //in V-if method
        checkReqChnlRowspan(reqChnl, index){
            var bfReqChnl = 0;

            if(reqChnl == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfReqChnl = this.zbil_chnl_ts_req_stc[index-1].reqChnl;

            if(bfReqChnl != reqChnl){
                return true;
            }

            return false;
        },

        getReqChnlRowspan(reqChnl){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_chnl_ts_req_stc.length; i++){
                if(this.zbil_chnl_ts_req_stc[i].reqChnl == reqChnl){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },
        
        //in V-if method
        checkNewChgClRowspan(reqChnl, newChgCl, index){
            var bfReqChnl = 0;
            var bfNewChgCl = 0;

            if(reqChnl == null){
                return;
            }

            if(newChgCl == null){
                return;
            }            

            if(index == 0){
                return true;
            }
            
            bfReqChnl = this.zbil_chnl_ts_req_stc[index-1].reqChnl;
            bfNewChgCl = this.zbil_chnl_ts_req_stc[index-1].newChgCl;

            if(bfReqChnl != reqChnl || bfNewChgCl != newChgCl){
                return true;
            }            
            return false;
        },

        getNewChgClRowspan(reqChnl, newChgCl){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_chnl_ts_req_stc.length; i++){
                if((this.zbil_chnl_ts_req_stc[i].reqChnl == reqChnl) && (this.zbil_chnl_ts_req_stc[i].newChgCl == newChgCl)){
                    rowspanValue++;
                    // console.log("rowspanValue:" + rowspanValue + " reqChnl: " + reqChnl + " newChgCl: " + newChgCl);
                }
            }

            // console.log("rowspanValue : " + rowspanValue);

            return rowspanValue;
        },

        CommaFormat : function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },
        
        makeChartData: function() {
            console.log("in calChartSum()");

            var curReqChnl = '';
            var bfReqChnl = '';
            var sumReqCnt = 0;
            this.ArrChartLabel = [];
            this.ArrChartDataReqCnt = [];
            
            for(var i=0; i<this.zbil_chnl_ts_req_stc.length; i++){      
                curReqChnl = this.zbil_chnl_ts_req_stc[i].reqChnl;
                
                if( i > 0) {
                    bfReqChnl = this.zbil_chnl_ts_req_stc[i-1].reqChnl;
                }

                if( i > 0 && bfReqChnl != curReqChnl ){
                    console.log("if");
                    this.ArrChartLabel.push( bfReqChnl );
                    this.ArrChartDataReqCnt.push( sumReqCnt );
                    sumReqCnt = 0;
                    console.log("diff: "+curReqChnl+" sumReqCnt: "+sumReqCnt);
                }
                
                console.log("same1: "+curReqChnl+" sumReqCnt: "+sumReqCnt);
                sumReqCnt += parseInt(this.zbil_chnl_ts_req_stc[i].reqCnt.replaceAll(',',''));
                

                if( i == this.zbil_chnl_ts_req_stc.length-1 ) {
                    this.ArrChartLabel.push( curReqChnl );
                    this.ArrChartDataReqCnt.push( sumReqCnt );                    
                }

                console.log("same2: "+curReqChnl+" sumReqCnt: "+sumReqCnt);
            }
        },

        renderChart: function() {
            console.log("in renderChart");

            let chartData2 = {
                labels: this.ArrChartLabel,
                datasets: [
                    {
                        label: "신청건수",
                        backgroundColor: ["#ea002c", "#eb8439", "#f9b310","#5978f5","#755dd8","#425a78","#b061e4","#61a4b2","#857979","#b7b7b7"],
                        data: this.ArrChartDataReqCnt,
                    }
                ]
            };
            this.chartData = chartData2;
        },        

    },

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search();        
    },    

};

</script>