<template>
        <div class="content animated fadeInUp">
            <div class="cont-top">
                <h2 class="tit">인출오류 유형별 현황</h2>
                <ul class="navigation">
                    <li><i class="ri-home-4-line"></i></li>
                    <li>Data Analysis</li>
                    <li>카드자동납부 인출오류 분석</li>
                    <li>인출오류 유형별 현황</li>
                </ul>
            </div>
            <!-- //cont-top -->
            <div class="search-area">
                <div class="search-list">
                    <ul class="search-item">
                        <li>
                            <label>인출월</label>
                            <span class="datepick-custom">
                                <date-picker v-model="dateDrwYm" type="month"></date-picker>
                                <i class="ri-calendar-line"></i>
                            </span>
                        </li>
                        <li>
                            <label>카드사</label>
                            <span class="select-custom">
                                <select id='selectCardNm' @change="changeCardNm($event)">
                                    <option value='전체' selected>전체</option>
                                    <option value='삼성카드'>삼성카드</option>
                                    <option value='신한카드'>신한카드</option>
                                    <option value='롯데카드'>롯데카드</option>
                                    <option value='현대카드'>현대카드</option>
                                    <option value='BC카드'>BC카드</option>
                                    <option value='국민카드'>국민카드</option>
                                    <option value='하나카드(구외환)'>하나카드(구외환)</option>
                                    <option value='씨티카드'>씨티카드</option>
                                    <option value='NH카드'>NH카드</option>
                                    <option value='하나카드'>하나카드</option>
                                </select>
                            </span>
                        </li>
                        <li>
                            <label>오류유형</label>
                            <span class="select-custom">
                                <select id='selectCardErrTypNm' @change="changeCardErrTypNm($event)">
                                    <option value='전체' selected>전체</option>
                                    <option value='거래정지'>거래정지</option>
                                    <option value='한도초과'>한도초과</option>
                                    <option value='유효기간경과'>유효기간경과</option>
                                    <option value='분실도난카드'>분실도난카드</option>
                                    <option value='미등록카드/회원'>미등록카드/회원</option>
                                    <option value='기타오류'>기타오류</option>
                                </select>
                            </span>                            
                        </li>
                    </ul>
                </div>
                <div class="search-btn">
                    <button v-on:click="Onclick_search"><em><i class="ri-search-line"></i>검색</em></button>
                </div>
            </div>
            <!-- //search-area -->         


                    <!-- <tr class="total org"> -->
                    <!-- <td class="t-bold b-lt t-lt">미등록카드정보</td> -->

            <table class="tbl t-ct">
                <colgroup>
                    <col style="width:180px">
                    <col>
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                    <col style="width:11%">
                </colgroup>
                <thead>
                    <tr>
                        <th>카드사</th>
                        <th>오류유형</th>
                        <th id='drwYm1'>20년 06월</th>
                        <th id='drwYm2'>20년 07월</th>
                        <th id='drwYm3'>20년 08월</th>
                        <th id='drwYm4'>20년 09월</th>
                        <th id='drwYm5'>20년 10월</th>
                        <th id='drwYm6'>20년 11월</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(table,i) in zbil_drw_err_typ_stc" :key="i">
                        <template v-if="checkCardNmRowspan(table.cardNm, i) == true">
                            <td class="t-bold t-ct" :rowspan="getCardNmRowspan(table.cardNm)">{{table.cardNm}}</td>
                        </template>
                        <template v-if="table.cardErrTypNm == '소계'">
                            <td class="t-ct subTotalTd">{{table.cardErrTypNm}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm1}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm2}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm3}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm4}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm5}}</td>
                            <td class="t-rt subTotalTd">{{table.drwYm6}}</td>
                        </template>
                        <template v-else>
                            <td class="t-ct">{{table.cardErrTypNm}}</td>
                            <td class="t-rt">{{table.drwYm1}}</td>
                            <td class="t-rt">{{table.drwYm2}}</td>
                            <td class="t-rt">{{table.drwYm3}}</td>
                            <td class="t-rt">{{table.drwYm4}}</td>
                            <td class="t-rt">{{table.drwYm5}}</td>
                            <td class="t-rt">{{table.drwYm6}}</td>
                        </template>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td class="t-ct" :colspan="2">합계</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[0]}}</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[1]}}</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[2]}}</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[3]}}</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[4]}}</td>
                        <td class="t-rt">{{this.zbil_drw_err_typ_stc_total[5]}}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
</template>

<script>
import axios from 'axios';
import $ from 'jquery';
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import 'vue2-datepicker/locale/ko';

export default {
    components: {
       DatePicker,
    },
    data() {
        return {
            dateDrwYm: new Date(),
            drwYm: '202011',
            cardNm: '전체',
            cardErrTypNm: '전체',
            zbil_drw_err_typ_stc: {
                cardNm :[],
                cardErrTypNm :[],
                drwYm1 :[],
                drwYm2 :[],
                drwYm3 :[],
                drwYm4 :[],
                drwYm5 :[],
                drwYm6 :[],
            },
            zbil_drw_err_typ_stc_total: [],
            arr_drwYm: [],
        };
    },
 
   methods: {
        Onclick_search: function () {
            console.log('in Onclick_search');

            var tmpDrwYmYear   = 0;
            var tmpDrwYmMonth  = 0;

            tmpDrwYmYear = '' + this.dateDrwYm.getFullYear();

            if(this.dateDrwYm.getMonth()+1 < 10){
                tmpDrwYmMonth = '0' + (this.dateDrwYm.getMonth()+1);
            }else{
                tmpDrwYmMonth = this.dateDrwYm.getMonth()+1;
            }

            this.drwYm = tmpDrwYmYear+tmpDrwYmMonth;

            console.log('drwYm : ' + this.drwYm);
            console.log('cardNm : ' + this.cardNm);
            console.log('cardErrTypNm : ' + this.cardErrTypNm);

            axios.post('http://13.124.162.248:5000/zbil_drw_err_typ_stc', {drwYm: this.drwYm, cardNm: this.cardNm, cardErrTypNm: this.cardErrTypNm }).then(res => {
                console.log(res);

                if(res.data.length == 0){
                    alert('조회된 결과가 없습니다.');
                    console.log('결과없음');
                    return;
                }
                
                // Grid Data Setting
                this.zbil_drw_err_typ_stc = res.data;

                $("#selectDrwYm").value = this.drwYm;                
                $("#selectCardNm").value = this.cardNm;
                $("#selectCardErrTypNm").value = this.cardErrTypNm;

                // Caluate SubTotal
                this.calTotal();

                // Setting DrwYm Value
                this.setDrwYmValue(this.drwYm);
            });
        },

        // 숫자에 콤마 추가
        CommaFormat : function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        // Caluate Total
        calTotal: function(){
            var tempTotalm1 = 0;
            var tempTotalm2 = 0;
            var tempTotalm3 = 0;
            var tempTotalm4 = 0;
            var tempTotalm5 = 0;
            var tempTotalm6 = 0;

            this.zbil_drw_err_typ_stc_total = [];

            // cardErrTypNm이 소계일때만 누적
            for(var i=0; i<this.zbil_drw_err_typ_stc.length; i++){
                if(this.zbil_drw_err_typ_stc[i].cardErrTypNm == '소계' ){
                    console.log("in if")
                    tempTotalm1  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm1.replace(/,/gi, ""));   
                    tempTotalm2  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm2.replace(/,/gi, ""));
                    tempTotalm3  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm3.replace(/,/gi, ""));
                    tempTotalm4  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm4.replace(/,/gi, ""));
                    tempTotalm5  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm5.replace(/,/gi, ""));
                    tempTotalm6  += parseInt(this.zbil_drw_err_typ_stc[i].drwYm6.replace(/,/gi, ""));
                }
            }

            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm1) );
            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm2) );
            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm3) );
            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm4) );
            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm5) );
            this.zbil_drw_err_typ_stc_total.push( this.CommaFormat(tempTotalm6) );
        },

        // Caluate Total
        setDrwYmValue: function(drwYm){
            var date = new Date(drwYm.substr(0,4)+'-'+drwYm.substr(4,2)+'-01');

            var yymm1 = 0;
            var yymm2 = 0;
            var yymm3 = 0;
            var yymm4 = 0;
            var yymm5 = 0;
            var yymm6 = this.drwYm;
            
            date.setMonth(date.getMonth() - 1);
            yymm5 = date.getFullYear() +''+ (  ( (date.getMonth() + 1) > 9 ) ? (date.getMonth() + 1) : ( "0" + (date.getMonth() + 1) ) ) ;

            date.setMonth(date.getMonth() - 1);
            yymm4 = date.getFullYear() +''+ (  ( (date.getMonth() + 1) > 9 ) ? (date.getMonth() + 1) : ( "0" + (date.getMonth() + 1) ) ) ;

            date.setMonth(date.getMonth() - 1);
            yymm3 = date.getFullYear() +''+ (  ( (date.getMonth() + 1) > 9 ) ? (date.getMonth() + 1) : ( "0" + (date.getMonth() + 1) ) ) ;

            date.setMonth(date.getMonth() - 1);
            yymm2 = date.getFullYear() +''+ (  ( (date.getMonth() + 1) > 9 ) ? (date.getMonth() + 1) : ( "0" + (date.getMonth() + 1) ) ) ;

            date.setMonth(date.getMonth() - 1);
            yymm1 = date.getFullYear() +''+ (  ( (date.getMonth() + 1) > 9 ) ? (date.getMonth() + 1) : ( "0" + (date.getMonth() + 1) ) ) ;

            $("#drwYm1").html(yymm1.substr(2,2) + "년 " + yymm1.substr(4,2) + "월");
            $("#drwYm2").html(yymm2.substr(2,2) + "년 " + yymm2.substr(4,2) + "월");
            $("#drwYm3").html(yymm3.substr(2,2) + "년 " + yymm3.substr(4,2) + "월");
            $("#drwYm4").html(yymm4.substr(2,2) + "년 " + yymm4.substr(4,2) + "월");
            $("#drwYm5").html(yymm5.substr(2,2) + "년 " + yymm5.substr(4,2) + "월");
            $("#drwYm6").html(yymm6.substr(2,2) + "년 " + yymm6.substr(4,2) + "월");
        },

        //Changed CardNm
        changeCardNm: function(event){
            console.log("Before : " + this.cardNm);
            this.cardNm = event.target.value;
            console.log("After : " + this.cardNm);
        },

        //Changed CardErrTypNm
        changeCardErrTypNm: function(event){
            console.log("Before : " + this.cardErrTypNm);
            this.cardErrTypNm = event.target.value;
            console.log("After : " + this.cardErrTypNm);
        }, 

        //in V-if method
        checkCardNmRowspan(cardNm, index){
            var bfCardNm = 0;

            if(cardNm == null){
                return;
            }
            
            if(index == 0){
                return true;
            }
            
            bfCardNm = this.zbil_drw_err_typ_stc[index-1].cardNm;

            if(bfCardNm != cardNm){
                return true;
            }            
            return false;
        },

        getCardNmRowspan(cardNm){
            var rowspanValue = 0;

            for(var i=0; i<this.zbil_drw_err_typ_stc.length; i++){
                if(this.zbil_drw_err_typ_stc[i].cardNm == cardNm){
                    rowspanValue++;
                }
            }

            return rowspanValue;
        },
    },     

    mounted() {
        $('.month-btn button').click(function(){
            $('.month-btn button').removeClass('on');
            $(this).addClass('on');  
        });

        this.Onclick_search(); 
    }
};

</script>