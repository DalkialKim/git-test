package maskShop3;

import javax.persistence.*;

import maskShop3.external.Delivery;
import maskShop3.external.Inventory;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Order_table")
public class Order {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long orderId;
    private Long productId;
    private Integer qty;

    @PostPersist
    public void onPostPersist(){

        // order -> inventory update
        maskShop3.external.Inventory inventory = new maskShop3.external.Inventory();
        inventory.setProductId(getProductId());
        inventory.setInvQty(inventory.getInvQty()- getQty());
        OrderApplication.applicationContext.getBean(maskShop3.external.InventoryService.class).update(inventory);

        // order -> delivery create
        maskShop3.external.Delivery delivery = new maskShop3.external.Delivery();
        delivery.setOrderId(getOrderId());
        //delivery.setOrderId(getId());
        delivery.setStatus("SHIPPED");

        OrderApplication.applicationContext.getBean(maskShop3.external.DeliveryService.class).update(delivery);
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Integer getQty() {
        return qty;
    }
    public void setQty(Integer qty) {
        this.qty = qty;
    }


}
